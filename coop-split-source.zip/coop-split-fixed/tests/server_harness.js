'use strict';
const vm = require('node:vm');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const {EventEmitter} = require('node:events');
const net = {}, events = {}, commands = {}, sent = [];
let socket, polls, passed = 0;
const players = ['1', '2'];
const context = {
    require(name) { assert.equal(name, 'dgram'); return {createSocket() {
        socket = new EventEmitter(); socket.bind = () => socket.emit('listening'); socket.close = () => {};
        return socket;
    }}; },
    console: {log() {}}, Buffer, Date,
    GetConvar: (_, d) => d,
    GetNumPlayerIndices: () => players.length,
    GetPlayerFromIndex: i => players[i],
    GetPlayerName: id => players.includes(String(id)) ? `p${id}` : null,
    GetCurrentResourceName: () => 'coop_input',
    emitNet: (...args) => sent.push(args),
    onNet: (name, cb) => net[name] = cb,
    on: (name, cb) => events[name] = cb,
    RegisterCommand: (name, cb) => commands[name] = cb,
    setImmediate: fn => fn(), setInterval: fn => {polls=fn;},
};
vm.createContext(context);
vm.runInContext(fs.readFileSync('coop_input/server.js','utf8'),context);
function check(ok, label) {assert.ok(ok, label);passed++;console.log('PASS '+label);}
const neutral = {lx:0,ly:0,rx:0,ry:0,lt:0,rt:0,buttons:0};
function packet(obj) {
    sent.length=0;socket.emit('message',Buffer.from(JSON.stringify(obj)),{address:'127.0.0.1'});
    return sent.filter(e=>e[0]==='coop_input:updateState');
}
check(packet(neutral).length===1,'valid packet forwarded once');
let received = packet({...neutral,rt:1,lx:-0.5})[0];
check(received[1]==='2' && received[2].rt===1 && received[2].lx===-0.5,'normalized driving packet reaches only P2');
check(packet({ry:1}).length===0,'partial snapshot rejected');
check(packet({...neutral,ry:32767}).length===0,'raw unsigned axis rejected');
check(packet({...neutral,rt:-1}).length===0,'negative normalized trigger rejected');
check(packet({...neutral,buttons:1.5}).length===0,'fractional button mask rejected');
check(packet({...neutral,lx:'0'}).length===0,'non-number rejected');
sent.length=0;socket.emit('message',Buffer.from('{bad'),{address:'127.0.0.1'});
check(sent.length===0,'broken JSON rejected');
sent.length=0;socket.emit('message',Buffer.from(JSON.stringify(neutral)),{address:'10.0.0.1'});
check(sent.length===0,'non-loopback source rejected');
commands.setp2(0,['0']);check(packet(neutral).length===0,'setp2 0 disables forwarding');
commands.setp2(0,['auto']);check(packet(neutral)[0][1]==='2','auto restores P2 selection');
context.source=1;net['coop_input:registerClient'](2);
check(packet(neutral)[0][1]==='1','explicit coop_slot 2 selects registered client');
commands.setp2(0,['2']);check(packet(neutral)[0][1]==='2','manual selection overrides slot');
commands.setp2(1,['1']);check(packet(neutral)[0][1]==='2','player cannot run console-only role command');
polls();check(packet(neutral)[0][1]==='2','role polling preserves manual selection');
events.onResourceStop('coop_input');
check(sent.some(e=>e[0]==='coop_input:setRole' && e[2]===0),'resource stop clears P2 role');
console.log(`Completed ${passed} server checks; Cfx APIs and UDP socket mocked`);
