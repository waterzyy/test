-- Runs in Lua 5.3+ (or fengari); FiveM calls are simulated.
local events, commands, threads, controls = {}, {}, {}, {}
local now, veh, driver = 100, false, false
local camHeading, camPitch, camWrites = 0, 0, 0
function GetGameTimer() return now end
function GetHashKey(s) return s end
function GetPlayerServerId() return 2 end
function PlayerId() return 1 end
function PlayerPedId() return 42 end
function GetFrameTime() return 1/60 end
function IsEntityDead() return false end
function IsPauseMenuActive() return false end
function IsPedInAnyVehicle() return veh end
function GetVehiclePedIsIn() return veh and 100 or 0 end
function GetPedInVehicleSeat() return driver and 42 or 7 end
function GetCurrentPedWeapon() return true, 'WEAPON_UNARMED' end
function HasPedGotWeapon() return false end
function SetControlNormal(_, id, value) controls[id] = value; return true end
function SetGameplayCamRelativeHeading(v) camHeading=v;camWrites=camWrites+1 end
function SetGameplayCamRelativePitch(v) camPitch=v;camWrites=camWrites+1 end
function GetGameplayCamRelativeHeading() return camHeading end
function GetGameplayCamRelativePitch() return camPitch end
function RegisterNetEvent(n, fn) events[n] = fn end
function RegisterCommand(n, fn) commands[n] = fn end
function AddEventHandler() end
Citizen = {CreateThread=function(fn) threads[#threads+1] = coroutine.create(fn) end,
Wait=function() coroutine.yield() end}
assert(loadfile('coop_input/client.lua'))()
commands.coop_debug()
local co = threads[#threads]
assert(coroutine.resume(co))
local function tick(t)
    now = t; controls = {}
    local ok, err = coroutine.resume(co); assert(ok, err)
end
local function packet(p)
    local d = {lx=0,ly=0,rx=0,ry=0,lt=0,rt=0,buttons=0}
    for k,v in pairs(p or {}) do d[k]=v end
    events['coop_input:updateState'](d)
end
local function arm(t)
    now=t;packet();now=t+210;packet();tick(now)
end
local passed=0
local function check(ok, label) assert(ok, label);passed=passed+1;print('PASS '..label) end
-- Ignore input before role selection.
packet({rt=1});tick(110);check(next(controls)==nil,'inactive client receives no injected controls')
events['coop_input:setRole'](2,2)
now=120;packet({ry=1,rt=1});tick(120)
check(next(controls)==nil,'held/wrong startup axes cannot arm')
arm(130)
now=350;packet({ry=0.8});tick(350)
check(controls[2] and controls[2]<0,'right stick reaches native camera axis')
now=360;packet();tick(360)
check(controls[2]==0,'released camera stops immediately')
now=370;packet({ry=0.8});tick(370);tick(900)
check(next(controls)==nil,'camera-only stale packet stops input')
now=910;packet({rt=1});tick(910)
check(next(controls)==nil,'reconnection requires neutral state')
arm(920);veh=true;driver=true
now=1140;packet({rt=0.8,lt=0.2,lx=0.5});tick(1140)
check(controls[71]==0.8 and controls[72]==0.2 and controls[59]>0,'driver gas brake and steering')
check(controls[60]==nil,'walking axis not injected into vehicle pitch')
now=1150;packet({rt=0.8,buttons=0x100});tick(1150)
check(controls[69]==nil,'gas does not fire weapon while aiming')
check(controls[76]==0,'R1 does not engage handbrake')
driver=false;tick(1160)
check(controls[71]==nil and controls[59]==nil,'passenger cannot inject steering or gas')
veh=false
now=1170;events['coop_input:updateState']({lx=0});tick(1170)
check(next(controls)==nil,'partial packet fails closed')
arm(1180)
now=1400;packet({ry=0/0});tick(1400)
check(next(controls)==nil,'NaN packet fails closed')
arm(1410)
now=1630;packet({buttons=0x20});packet();tick(1630)
check(controls[0]==1,'short camera-switch press survives between frames')
tick(1640);check(controls[0]==nil,'camera-switch edge applied once')
commands.coop_profile(nil,{'ds4_unsigned'})
now=1700;packet({lx=.5,ly=.5,rx=.5,ry=.5});now=1910;packet({lx=.5,ly=.5,rx=.5,ry=.5});tick(1910)
check(controls[1]==0 and controls[2]==0,'unsigned DS4 sticks center at 0.5')
commands.coop_profile(nil,{'signed_triggers'})
now=2000;packet({lt=-1,rt=-1});now=2210;packet({lt=-1,rt=-1});tick(2210)
veh=true;driver=true;now=2220;packet({lt=-1,rt=1});tick(2220)
check(controls[71]==1 and controls[72]==0,'signed trigger profile maps released and pressed')
veh=false
commands.coop_profile(nil,{'xinput'});arm(2300)
commands.coop_camera(nil,{'manual'});camWrites=0
now=2520;packet({rx=0.8,ry=0.8});tick(2520)
check(camWrites==2 and controls[1]==nil and controls[2]==nil,'manual camera never also injects LOOK axes')
camWrites=0;now=2530;packet();tick(2530)
check(camWrites==0,'manual camera stops on neutral')
commands.coop_camera(nil,{'native'});camWrites=0
now=2540;packet({rx=0.8});tick(2540)
check(camWrites==0 and controls[1]>0,'native camera never manually rotates')
now=2550;packet({buttons=0x8000});packet();tick(2550)
check(controls[23]==1,'short enter-vehicle tap survives packet release before frame')
events['coop_input:setRole'](1,2);tick(2560)
check(next(controls)==nil,'role loss stops injected controls')
print(('Completed %d checks; FiveM/Windows integration NOT tested'):format(passed))
