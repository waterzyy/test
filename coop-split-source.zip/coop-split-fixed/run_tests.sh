#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
DOTNET="${DOTNET:-dotnet}"
LUA="${LUA:-}"
if [ -z "$LUA" ]; then
  for candidate in lua5.4 lua54 lua lua5.3 fengari; do
    if command -v "$candidate" >/dev/null 2>&1; then LUA="$candidate"; break; fi
  done
fi
if [ -z "$LUA" ]; then echo 'Lua 5.3+ required (or set LUA=/path/to/interpreter)' >&2; exit 1; fi
"$DOTNET" run --project CoopInputRouter -c Release -- --selftest
"$LUA" tests/client_harness.lua
node --check coop_input/server.js
node tests/server_harness.js
