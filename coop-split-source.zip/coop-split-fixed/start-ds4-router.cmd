@echo off
cd /d "%~dp0"
echo Start FXServer and ensure coop_input first. Close old router and x360ce.
echo Destination: 127.0.0.1:30126. Release sticks, triggers and buttons after connecting.
CoopInputRouter.exe --directinput --port 30126 --hz 60 %*
echo.
echo Router exited with code %errorlevel%.
pause
