-- coop_input client v3. Wire contract and installation: README_RU.md.
-- Does not read a physical DS4: requires your existing server/packet sender.
local CFG = {
    aim_slowdown     = 0.35,   -- Замедление прицела при зажатом L2

    stick_curve      = 2.0,    -- Мягкий центр стика для точной стрельбы
    deadzone_extra   = 0.04,   -- Дополнительная мертвая зона

    invert_look_y    = false,  -- Команда coop_invert переключит на лету

    camera_mode      = 'native', -- coop_camera manual for background-camera fallback
    stale_timeout    = 500,
    hud_default      = true,
}
-- ====================================================================

local XINPUT = {
    DPAD_UP    = 0x0001,
    DPAD_DOWN  = 0x0002,
    DPAD_LEFT  = 0x0004,
    DPAD_RIGHT = 0x0008,
    START      = 0x0010,
    BACK       = 0x0020,
    L3         = 0x0040,
    R3         = 0x0080,
    LB         = 0x0100,
    RB         = 0x0200,
    A          = 0x1000,   -- Крестик (PS4)
    B          = 0x2000,   -- Кружок (PS4)
    X          = 0x4000,   -- Квадрат (PS4)
    Y          = 0x8000,   -- Треугольник (PS4)
}

local C = {
    NEXT_CAMERA          = 0,
    LOOK_LR              = 1,
    LOOK_UD              = 2,
    WEAPON_WHEEL_UD      = 12,
    WEAPON_WHEEL_LR      = 13,
    WEAPON_WHEEL_NEXT    = 14,
    WEAPON_WHEEL_PREV    = 15,
    HUD_INFO             = 20,
    SPRINT               = 21,
    JUMP                 = 22,
    ENTER                = 23,
    ATTACK               = 24,
    AIM                  = 25,
    LOOK_BEHIND          = 26,
    PHONE                = 27,
    MOVE_LR              = 30,
    MOVE_UD              = 31,
    DUCK                 = 36,
    SELECT_WEAPON        = 37,
    COVER                = 44,
    RELOAD               = 45,
    TALK                 = 46,
    VEH_MOVE_LR          = 59,
    VEH_MOVE_UD          = 60,
    VEH_AIM              = 68,
    VEH_ATTACK           = 69,
    VEH_ACCELERATE       = 71,
    VEH_BRAKE            = 72,
    VEH_HEADLIGHT        = 74,
    VEH_EXIT             = 75,
    VEH_HANDBRAKE        = 76,
    VEH_LOOK_BEHIND      = 79,
    VEH_RADIO_WHEEL      = 85,
    VEH_HORN             = 86,
    VEH_SELECT_NEXT_WEAP = 99,
    MELEE_LIGHT          = 140,
}

-- ------------------------------------------------------------------
--  Состояние, проверка пакетов и включение после нейтрали
-- ------------------------------------------------------------------
local myServerId  = 0
local active      = false
local showHud     = CFG.hud_default
local lastPacket  = 0
local packetRate  = 0
local packetMark  = 0
local packetStamp = GetGameTimer()

local rawSt = { lx = 0.0, ly = 0.0, rx = 0.0, ry = 0.0, lt = 0.0, rt = 0.0, buttons = 0 }
local st    = { lx = 0.0, ly = 0.0, rx = 0.0, ry = 0.0, lt = 0.0, rt = 0.0, buttons = 0 }

-- All axes must be released together before input is enabled.
local profile = 'xinput' -- xinput: sticks -1..1, up positive; triggers 0..1
local armed, neutralSince = false, nil
local invalidPackets = 0
local lastError = 'waiting for packets'
local neutralHold = 200
local pendingButtons = 0
local framePressed = 0

local smoothRx, smoothRy = 0.0, 0.0

local function num(v) return tonumber(v) or 0.0 end

local function clampf(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end

local function resetState()
    st.lx, st.ly, st.rx, st.ry = 0.0, 0.0, 0.0, 0.0
    st.lt, st.rt, st.buttons = 0.0, 0.0, 0
    smoothRx, smoothRy = 0.0, 0.0
    pendingButtons, framePressed = 0, 0
    armed, neutralSince = false, nil
end

local function has(bit) return ((st.buttons | framePressed) & bit) ~= 0 end
local function justPressed(bit) return (framePressed & bit) ~= 0 end

local function processAxis(val, dz, curve)
    local a = math.abs(val)
    if a <= dz then return 0.0 end
    local norm = (a - dz) / (1.0 - dz)
    if norm > 1.0 then norm = 1.0 end
    local curved = norm ^ curve
    return (val < 0.0) and -curved or curved
end

-- Validate complete snapshots; never guess a controller axis mapping.
local function sanitizePacket(d)
    local p = {}
    for _, key in ipairs({'lx', 'ly', 'rx', 'ry', 'lt', 'rt', 'buttons'}) do
        local v = tonumber(d[key])
        if not v or v ~= v or math.abs(v) == math.huge then
            lastError = 'invalid or missing ' .. key
            return false
        end
        p[key] = v
    end
    if p.buttons < 0 or p.buttons > 65535 or p.buttons % 1 ~= 0 then
        lastError = 'buttons must be an XInput bitmask (0..65535)'
        return false
    end
    for _, key in ipairs({'lx', 'ly', 'rx', 'ry'}) do
        local lo = profile == 'ds4_unsigned' and 0 or -1
        if p[key] < lo or p[key] > 1 then
            lastError = 'stick out of range: ' .. key
            return false
        end
    end
    for _, key in ipairs({'lt', 'rt'}) do
        local lo = profile == 'signed_triggers' and -1 or 0
        if p[key] < lo or p[key] > 1 then
            lastError = 'trigger out of range: ' .. key
            return false
        end
    end
    for k, v in pairs(p) do rawSt[k] = v end
    if profile == 'ds4_unsigned' then
        p.lx, p.rx = p.lx * 2 - 1, p.rx * 2 - 1
        p.ly, p.ry = 1 - p.ly * 2, 1 - p.ry * 2
    elseif profile == 'ds4_signed' then
        p.ly, p.ry = -p.ly, -p.ry
    elseif profile == 'signed_triggers' then
        p.lt, p.rt = (p.lt + 1) / 2, (p.rt + 1) / 2
    end
    local now = GetGameTimer()
    if lastPacket ~= 0 and now - lastPacket > CFG.stale_timeout then resetState() end
    if not armed then
        local neutral = p.buttons == 0 and p.lt <= 0.08 and p.rt <= 0.08
        for _, k in ipairs({'lx', 'ly', 'rx', 'ry'}) do
            neutral = neutral and math.abs(p[k]) <= CFG.deadzone_extra
        end
        if neutral then
            neutralSince = neutralSince or now
            armed = now - neutralSince >= neutralHold
        else
            neutralSince = nil
        end
        if not armed then lastError = 'release ALL sticks, triggers and buttons'; return true end
    end
    pendingButtons = pendingButtons | (p.buttons & (~st.buttons))
    for k, v in pairs(p) do st[k] = v end
    lastError = 'OK'
    return true
end

-- ------------------------------------------------------------------
--  Список оружия для быстрого переключения (Крестовина Влево/Вправо)
-- ------------------------------------------------------------------
local WEAPON_HASHES = {
    GetHashKey("WEAPON_UNARMED"),
    GetHashKey("WEAPON_KNIFE"), GetHashKey("WEAPON_NIGHTSTICK"), GetHashKey("WEAPON_HAMMER"), GetHashKey("WEAPON_BAT"), GetHashKey("WEAPON_CROWBAR"), GetHashKey("WEAPON_MACHETE"),
    GetHashKey("WEAPON_PISTOL"), GetHashKey("WEAPON_PISTOL_MK2"), GetHashKey("WEAPON_COMBATPISTOL"), GetHashKey("WEAPON_APPISTOL"), GetHashKey("WEAPON_STUNGUN"), GetHashKey("WEAPON_PISTOL50"), GetHashKey("WEAPON_HEAVYPISTOL"), GetHashKey("WEAPON_REVOLVER"),
    GetHashKey("WEAPON_MICROSMG"), GetHashKey("WEAPON_SMG"), GetHashKey("WEAPON_ASSAULTSMG"), GetHashKey("WEAPON_COMBATPDW"), GetHashKey("WEAPON_MACHINEPISTOL"), GetHashKey("WEAPON_MINISMG"),
    GetHashKey("WEAPON_PUMPSHOTGUN"), GetHashKey("WEAPON_SAWNOFFSHOTGUN"), GetHashKey("WEAPON_ASSAULTSHOTGUN"), GetHashKey("WEAPON_BULLPUPSHOTGUN"), GetHashKey("WEAPON_HEAVYSHOTGUN"), GetHashKey("WEAPON_DBSHOTGUN"),
    GetHashKey("WEAPON_ASSAULTRIFLE"), GetHashKey("WEAPON_CARBINERIFLE"), GetHashKey("WEAPON_ADVANCEDRIFLE"), GetHashKey("WEAPON_SPECIALCARBINE"), GetHashKey("WEAPON_BULLPUPRIFLE"), GetHashKey("WEAPON_COMPACTRIFLE"),
    GetHashKey("WEAPON_MG"), GetHashKey("WEAPON_COMBATMG"), GetHashKey("WEAPON_GUSENBERG"),
    GetHashKey("WEAPON_SNIPERRIFLE"), GetHashKey("WEAPON_HEAVYSNIPER"), GetHashKey("WEAPON_MARKSMANRIFLE"),
    GetHashKey("WEAPON_RPG"), GetHashKey("WEAPON_GRENADELAUNCHER"), GetHashKey("WEAPON_MINIGUN"), GetHashKey("WEAPON_HOMINGLAUNCHER"), GetHashKey("WEAPON_COMPACTLAUNCHER"),
    GetHashKey("WEAPON_GRENADE"), GetHashKey("WEAPON_STICKYBOMB"), GetHashKey("WEAPON_SMOKEGRENADE"), GetHashKey("WEAPON_MOLOTOV"), GetHashKey("WEAPON_PROXMINE"), GetHashKey("WEAPON_PIPEBOMB")
}

local function cyclePlayerWeapon(ped, dir)
    local owned = {}
    for i = 1, #WEAPON_HASHES do
        local h = WEAPON_HASHES[i]
        if h == GetHashKey("WEAPON_UNARMED") or HasPedGotWeapon(ped, h, false) then
            owned[#owned + 1] = h
        end
    end
    if #owned <= 1 then return end

    local _, cur = GetCurrentPedWeapon(ped, true)
    local idx = 1
    for i = 1, #owned do
        if owned[i] == cur then
            idx = i
            break
        end
    end

    idx = idx + dir
    if idx > #owned then idx = 1 end
    if idx < 1 then idx = #owned end

    SetCurrentPedWeapon(ped, owned[idx], true)
end

-- ------------------------------------------------------------------
--  Камера: только нативные оси LOOK
-- ------------------------------------------------------------------
local function applyCamera(inVeh, isAiming, weaponWheelOpen)
    if weaponWheelOpen then
        smoothRx, smoothRy = 0.0, 0.0
        return
    end
    -- Exactly one camera path per frame: native LOOK or manual fallback.
    local tx = processAxis(st.rx, CFG.deadzone_extra, CFG.stick_curve)
    local ty = processAxis(st.ry, CFG.deadzone_extra, CFG.stick_curve)
    local alpha = 1 - math.exp(-math.min(GetFrameTime(), 0.1) / 0.035)
    smoothRx = tx == 0 and 0 or smoothRx + (tx - smoothRx) * alpha
    smoothRy = ty == 0 and 0 or smoothRy + (ty - smoothRy) * alpha
    local gain = isAiming and CFG.aim_slowdown or 1.0
    if CFG.camera_mode == 'native' then
        SetControlNormal(0, C.LOOK_LR, smoothRx * gain)
        SetControlNormal(0, C.LOOK_UD, smoothRy * (CFG.invert_look_y and 1 or -1) * gain)
    else
        -- Exclusive fallback for builds where LOOK input is muted in background.
        -- Never inject LOOK axes and manually rotate the camera in one frame.
        local dt = math.min(GetFrameTime(), 0.05)
        if smoothRx ~= 0 then
            SetGameplayCamRelativeHeading(GetGameplayCamRelativeHeading() - smoothRx * gain * (inVeh and 135 or 180) * dt)
        end
        if smoothRy ~= 0 then
            local y = smoothRy * (CFG.invert_look_y and -1 or 1)
            SetGameplayCamRelativePitch(clampf(GetGameplayCamRelativePitch() + y * gain * 100 * dt, -65, 55), 1.0)
        end
    end
end

-- ------------------------------------------------------------------
--  Применение управления
-- ------------------------------------------------------------------
local function applyInput(ped, inVeh, driving)
    local lx = processAxis(st.lx, CFG.deadzone_extra, 1.25)
    local ly = processAxis(st.ly, CFG.deadzone_extra, 1.25)

    local weaponWheelOpen = (not inVeh) and has(XINPUT.LB)
    local isAiming = (not inVeh and st.lt > 0.15) or (inVeh and has(XINPUT.LB))

    if justPressed(XINPUT.BACK) then
        SetControlNormal(0, C.NEXT_CAMERA, 1.0)
    end

    if not inVeh then
        -- В GTA V ось MOVE_UD: отрицательное значение = бежать вперед, положительное = назад
        SetControlNormal(0, C.MOVE_LR, lx)
        SetControlNormal(0, C.MOVE_UD, -ly)

        SetControlNormal(0, C.SPRINT, has(XINPUT.A) and 1.0 or 0.0)
        SetControlNormal(0, C.JUMP,   has(XINPUT.X) and 1.0 or 0.0)
        SetControlNormal(0, C.ENTER,  has(XINPUT.Y) and 1.0 or 0.0)
        SetControlNormal(0, C.COVER,  (has(XINPUT.RB) and not weaponWheelOpen) and 1.0 or 0.0)
        SetControlNormal(0, C.DUCK,   has(XINPUT.L3) and 1.0 or 0.0)

        local _, curWeap = GetCurrentPedWeapon(ped, true)
        local isUnarmed = (curWeap == GetHashKey("WEAPON_UNARMED"))
        if has(XINPUT.B) then
            if isUnarmed and not isAiming then
                SetControlNormal(0, C.MELEE_LIGHT, 1.0)
            else
                SetControlNormal(0, C.RELOAD, 1.0)
            end
        end

        if weaponWheelOpen then
            SetControlNormal(0, C.SELECT_WEAPON, 1.0)
            SetControlNormal(0, C.WEAPON_WHEEL_LR, st.rx)
            SetControlNormal(0, C.WEAPON_WHEEL_UD, -st.ry)

            if justPressed(XINPUT.DPAD_RIGHT) or justPressed(XINPUT.RB) then
                SetControlNormal(0, C.WEAPON_WHEEL_NEXT, 1.0)
            elseif justPressed(XINPUT.DPAD_LEFT) then
                SetControlNormal(0, C.WEAPON_WHEEL_PREV, 1.0)
            end
        else
            if justPressed(XINPUT.DPAD_LEFT) then
                cyclePlayerWeapon(ped, -1)
            elseif justPressed(XINPUT.DPAD_RIGHT) and not isAiming then
                cyclePlayerWeapon(ped, 1)
            end

            SetControlNormal(0, C.PHONE,    has(XINPUT.DPAD_UP) and 1.0 or 0.0)
            SetControlNormal(0, C.HUD_INFO, has(XINPUT.DPAD_DOWN) and 1.0 or 0.0)
            if isAiming and has(XINPUT.DPAD_RIGHT) then
                SetControlNormal(0, C.TALK, 1.0)
            end
        end

        if st.lt > 0.15 then
            SetControlNormal(0, C.AIM, 1.0)
        end
        if st.rt > 0.15 then
            SetControlNormal(0, C.ATTACK, st.rt)
        end
    else
        -- В МАШИНЕ
        local steer = processAxis(st.lx, CFG.deadzone_extra, 1.55)
        if driving then SetControlNormal(0, C.VEH_MOVE_LR, steer) end
        -- Do not inject VEH_MOVE_UD from the walking stick into road vehicles.

        if driving then
            SetControlNormal(0, C.VEH_ACCELERATE, st.rt)
            SetControlNormal(0, C.VEH_BRAKE,      st.lt)

            local handbrake = has(XINPUT.A) and 1.0 or 0.0
            SetControlNormal(0, C.VEH_HANDBRAKE,   handbrake)
            SetControlNormal(0, C.VEH_EXIT,        has(XINPUT.Y) and 1.0 or 0.0)
            SetControlNormal(0, C.VEH_HORN,        has(XINPUT.L3) and 1.0 or 0.0)
            SetControlNormal(0, C.VEH_HEADLIGHT,   has(XINPUT.DPAD_RIGHT) and 1.0 or 0.0)
            SetControlNormal(0, C.VEH_RADIO_WHEEL, has(XINPUT.DPAD_LEFT) and 1.0 or 0.0)
            SetControlNormal(0, C.VEH_LOOK_BEHIND, has(XINPUT.R3) and 1.0 or 0.0)
        else
            SetControlNormal(0, C.VEH_EXIT, has(XINPUT.Y) and 1.0 or 0.0)
        end

        if justPressed(XINPUT.X) then
            SetControlNormal(0, C.VEH_SELECT_NEXT_WEAP, 1.0)
            cyclePlayerWeapon(ped, 1)
        end

        if has(XINPUT.LB) then
            SetControlNormal(0, C.VEH_AIM, 1.0)
            if has(XINPUT.RB) then
                SetControlNormal(0, C.VEH_ATTACK, 1.0)
            end
        end
    end

    applyCamera(inVeh, isAiming, weaponWheelOpen)
end

-- ------------------------------------------------------------------
--  HUD отладки
-- ------------------------------------------------------------------
local function drawHud(now, driving)
    local stale = (lastPacket == 0) or ((now - lastPacket) > CFG.stale_timeout)
    local lockWarn = armed and (' [' .. profile .. ']') or ' [NOT ARMED - RELEASE ALL INPUTS]'

    SetTextFont(4)
    SetTextScale(0.0, 0.32)
    SetTextColour(255, 255, 255, 220)
    SetTextOutline()
    SetTextEntry('STRING')
    AddTextComponentString(('P2 PAD  %d pkt/s%s%s\nL %.2f %.2f   R %.2f %.2f\nLT %.2f  RT %.2f  btn 0x%04X\n%s'):format(
        packetRate,
        stale and '  [STALE]' or '',
        lockWarn,
        st.lx, st.ly, st.rx, st.ry,
        st.lt, st.rt, st.buttons & 0xFFFF,
        (driving and 'driving' or (IsPedInAnyVehicle(PlayerPedId(), false) and 'passenger' or 'on foot')) .. (' | bad=%d %s | RAW R %.2f %.2f T %.2f %.2f'):format(invalidPackets, lastError, rawSt.rx, rawSt.ry, rawSt.lt, rawSt.rt)
    ))
    DrawText(0.50, 0.02)
end

-- ------------------------------------------------------------------
--  Сетевые события
-- ------------------------------------------------------------------
RegisterNetEvent('coop_input:setRole', function(role, p2Id)
    myServerId = GetPlayerServerId(PlayerId())
    local r = num(role)
    local p2 = p2Id and tonumber(p2Id) or nil
    local iAmP2 = (r == 2) and (p2 == myServerId)

    if iAmP2 ~= active then
        active = iAmP2
        resetState()
        lastPacket = 0
        if active then
            SetGameplayCamRelativeHeading(0.0)
            SetGameplayCamRelativePitch(0.0, 1.0)
            print(('[coop_input] client %d is now PLAYER 2 - gamepad active'):format(myServerId))
        end
    end
end)

RegisterNetEvent('coop_input:updateState', function(data)
    if not active or type(data) ~= 'table' then return end
    if not sanitizePacket(data) then
        invalidPackets = invalidPackets + 1
        resetState()
        lastPacket = 0
        return
    end
    lastPacket = GetGameTimer()
    packetMark = packetMark + 1
end)

Citizen.CreateThread(function()
    while not NetworkIsSessionStarted() do Citizen.Wait(100) end
    myServerId = GetPlayerServerId(PlayerId())
    local slot = num(GetConvar('coop_slot', '0'))
    TriggerServerEvent('coop_input:registerClient', slot)
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    active = false
    resetState()
end)

RegisterCommand('coop_debug', function()
    showHud = not showHud
end, false)

RegisterCommand('coop_invert', function()
    CFG.invert_look_y = not CFG.invert_look_y
    print('[coop_input] Invert Y: ' .. tostring(CFG.invert_look_y))
end, false)

RegisterCommand('coop_camera', function(_, args)
    if args[1] ~= 'native' and args[1] ~= 'manual' then
        print('[coop_input] coop_camera native|manual')
        return
    end
    CFG.camera_mode = args[1]
    smoothRx, smoothRy = 0, 0
    print('[coop_input] camera: ' .. CFG.camera_mode)
end, false)

RegisterCommand('coop_profile', function(_, args)
    local p = args[1]
    if p ~= 'xinput' and p ~= 'ds4_signed' and p ~= 'ds4_unsigned' and p ~= 'signed_triggers' then
        print('[coop_input] coop_profile xinput|ds4_signed|ds4_unsigned|signed_triggers')
        return
    end
    profile = p
    resetState()
    lastPacket = 0
    print('[coop_input] profile: ' .. profile .. '; release all inputs')
end, false)

RegisterCommand('coop_calibrate', function()
    resetState()
    lastPacket = 0
    print('[coop_input] release all controls for 200 ms; wrong axes require sender correction')
end, false)

RegisterCommand('coop_resetcam', function()
    if not active then return end
    SetGameplayCamRelativeHeading(0.0)
    SetGameplayCamRelativePitch(0.0, 1.0)
end, false)

-- ------------------------------------------------------------------
--  Главный цикл
-- ------------------------------------------------------------------
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        local now = GetGameTimer()

        if lastPacket ~= 0 and (now - lastPacket) > CFG.stale_timeout then
            resetState()
            lastPacket = 0
            lastError = 'packet timeout'
        end

        if (now - packetStamp) >= 1000 then
            packetRate = packetMark
            packetMark = 0
            packetStamp = now
        end

        if active then
            local ped = PlayerPedId()
            local dead = IsEntityDead(ped)
            local paused = IsPauseMenuActive()
            local inVeh = IsPedInAnyVehicle(ped, false)
            local driving = false
            if inVeh then
                local veh = GetVehiclePedIsIn(ped, false)
                driving = veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped
            end

            if dead or paused then
                resetState()
            elseif armed and lastPacket ~= 0 then
                framePressed = pendingButtons
                pendingButtons = 0
                applyInput(ped, inVeh, driving)
            end

            if showHud then drawHud(now, driving) end
        end
    end
end)