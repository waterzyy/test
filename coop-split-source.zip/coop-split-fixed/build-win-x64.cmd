@echo off
REM =====================================================================
REM  Builds the standalone router. Requires the .NET 8 SDK (dotnet --info).
REM  Includes XInput mode and optional --directinput mode for a USB DS4.
REM  Output: ..\CoopInputRouter.exe (single-file, self-contained win-x64)
REM =====================================================================
cd /d "%~dp0CoopInputRouter"

dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true

if errorlevel 1 (
    echo.
    echo BUILD FAILED
    exit /b 1
)

copy /Y "bin\Release\net8.0\win-x64\publish\CoopInputRouter.exe" "..\CoopInputRouter.exe" >nul
if errorlevel 1 (
    echo.
    echo Could not copy the built exe to the coop-split folder.
    exit /b 1
)

echo.
echo Built: CoopInputRouter.exe
"..\CoopInputRouter.exe" --selftest
if errorlevel 1 exit /b 1

echo Test the direct DS4 reader (close x360ce first):
echo     CoopInputRouter.exe --directinput --port 30126

echo.
echo Optional - run the built-in verification suite:
echo     dotnet run -c Release -- --selftest
