@echo off
cd /d "%~dp0"
echo Close the usual router first. Test each stick and trigger separately.
echo RAW values and normalized JSON will print once per second.
CoopInputRouter.exe --directinput --port 30126 --hz 60 --diagnostics %*
echo.
echo Router exited with code %errorlevel%.
pause
