// DirectInput reader for a physical DualShock 4.
// This bypasses x360ce and XInput slot numbering entirely. It reads the USB
// Wireless Controller through DirectInput in non-exclusive background mode,
// validates driver ranges and maps configurable axes / POV / buttons,
// and feeds the existing XInput-shaped packet serializer.

using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Di = SharpDX.DirectInput;

namespace CoopInputRouter;

internal sealed class DirectInputSource : IXInputSource, IDisposable
{
    private readonly Di.DirectInput _directInput;
    private readonly string _deviceMatch;
    private readonly int _targetSlot;
    private readonly bool _invertY;
    private readonly IntPtr _windowHandle;
    private Di.Joystick? _joystick;
    private string? _productName;
    private string? _instanceName;
    private long _nextSearchMs;
    private bool _disposed;
    private readonly string[] _axes;
    private readonly bool _diagnostics;
    private long _lastDiagnostic;
    private string _lastFailure = "";
    private readonly Dictionary<string, Di.InputRange> _ranges = new();
    internal static readonly string[] StandardAxes = { "X", "Y", "Z", "RotationZ", "RotationX", "RotationY" };
    internal static bool ValidAxis(string name) => StandardAxes.Contains(name, StringComparer.Ordinal);

    [DllImport("kernel32.dll", ExactSpelling = true)]
    private static extern IntPtr GetConsoleWindow();

    public DirectInputSource(string deviceMatch, int targetSlot, bool invertY, string[]? axes = null, bool diagnostics = false)
    {
        _axes = axes ?? StandardAxes;
        if (_axes.Length != 6 || _axes.Any(a => !ValidAxis(a)) || _axes.Distinct().Count() != 6)
            throw new ArgumentException("--axes requires six distinct names: X,Y,Z,RotationX,RotationY,RotationZ");
        _diagnostics = diagnostics;
        _directInput = new Di.DirectInput();
        _deviceMatch = deviceMatch.Trim();
        _targetSlot = targetSlot;
        _invertY = invertY;
        _windowHandle = GetConsoleWindow();
        _nextSearchMs = 0;
    }

    public string InputDescription => _productName == null
        ? $"DirectInput — ожидание '{_deviceMatch}'"
        : $"DirectInput — {_productName}";

    public string DescribeSlot(int slot) => _productName == null
        ? "DirectInput device"
        : $"DirectInput device '{_productName}'";

    public bool TryGetState(int slot, out XINPUT_STATE state)
    {
        state = default;
        if (_disposed || slot != _targetSlot) return false;

        long now = Environment.TickCount64;
        if (_joystick == null)
        {
            if (now < _nextSearchMs) return false;
            _nextSearchMs = now + 1000;
            TryOpenDevice();
            if (_joystick == null) return false;
        }

        try
        {
            _joystick.Poll();
            Di.JoystickState s = _joystick.GetCurrentState();
            int Read(string name) => ReadAxis(s, name);
            short Axis(int n) {
                var range = _ranges[_axes[n]];
                return NormalizeAxis(Read(_axes[n]), range.Minimum, range.Maximum);
            }
            state = MapRawState(Axis(0), Axis(1), Axis(2), Axis(4), Axis(5), Axis(3),
                s.Buttons, s.PointOfViewControllers, _invertY);
            if (_diagnostics && now - _lastDiagnostic >= 1000)
            {
                _lastDiagnostic = now;
                var packet = PadMapping.FromRaw(in state);
                Console.WriteLine($"[DS4 raw] X={s.X} Y={s.Y} Z={s.Z} Rx={s.RotationX} Ry={s.RotationY} Rz={s.RotationZ}");
                Console.WriteLine("[DS4 packet] " + PacketSerializer.ToJson(in packet));
            }
            return true;
        }
        catch (Exception ex)
        {
            ReportFailure(ex);
            // A disconnect, a temporary acquisition loss, or an unplug should
            // become a neutral packet; then search again instead of crashing.
            CloseJoystick();
            _nextSearchMs = Environment.TickCount64 + 750;
            return false;
        }
    }

    private void TryOpenDevice()
    {
        Di.DeviceInstance[] devices;
        try
        {
            devices = _directInput.GetDevices(
                Di.DeviceClass.GameControl,
                Di.DeviceEnumerationFlags.AttachedOnly).ToArray();
        }
        catch
        {
            return;
        }

        var candidates = string.IsNullOrWhiteSpace(_deviceMatch)
            ? devices
            : devices.Where(d => d.ProductName.Contains(_deviceMatch, StringComparison.OrdinalIgnoreCase)).ToArray();

        foreach (var info in candidates)
        {
            Di.Joystick? candidate = null;
            try
            {
                candidate = new Di.Joystick(_directInput, info.InstanceGuid);
                candidate.SetCooperativeLevel(
                    _windowHandle,
                    Di.CooperativeLevel.Background | Di.CooperativeLevel.NonExclusive);

                // Request a signed range, but never assume the driver accepted it.
                // Read back every mapped axis range even if setting it failed.
                _ranges.Clear();
                foreach (string name in _axes)
                {
                    var properties = candidate.GetObjectPropertiesByName(name);
                    try { properties.Range = new Di.InputRange(short.MinValue, short.MaxValue); }
                    catch (SharpDX.SharpDXException) { /* Read-only range is supported below. */ }
                    var range = properties.Range;
                    if (range.Maximum <= range.Minimum)
                        throw new InvalidOperationException($"Invalid range for {name}: {range.Minimum}..{range.Maximum}");
                    _ranges[name] = range;
                }

                candidate.Acquire();
                _joystick = candidate;
                _productName = info.ProductName;
                _instanceName = info.InstanceName;
                _lastFailure = "";
                Console.WriteLine($"[DS4] Opened {_productName}; axes LX,LY,RX,RY,LT,RT=" + string.Join(",", _axes));
                foreach (var entry in _ranges)
                    Console.WriteLine($"[DS4] {entry.Key} range {entry.Value.Minimum}..{entry.Value.Maximum}");
                return;
            }
            catch (Exception ex)
            {
                ReportFailure(ex);
                try { candidate?.Dispose(); } catch { }
            }
        }
    }

    private void ReportFailure(Exception ex)
    {
        string message = ex.GetType().Name + ": " + ex.Message;
        if (message == _lastFailure) return;
        _lastFailure = message;
        Console.Error.WriteLine("[DS4] " + message);
    }

    internal static int ReadAxis(Di.JoystickState s, string name) => name switch
    {
        "X" => s.X, "Y" => s.Y, "Z" => s.Z,
        "RotationX" => s.RotationX, "RotationY" => s.RotationY, "RotationZ" => s.RotationZ,
        _ => throw new ArgumentException("Unknown axis: " + name)
    };

    internal static short NormalizeAxis(int value, int minimum, int maximum)
    {
        if (maximum <= minimum) throw new ArgumentException("Invalid axis range");
        if (value < minimum || value > maximum)
            throw new ArgumentOutOfRangeException(nameof(value), "Axis value outside reported driver range");
        double unit = (value - (double)minimum) / ((double)maximum - minimum);
        return ToShort((long)Math.Round(unit * 65535.0 - 32768.0, MidpointRounding.AwayFromZero));
    }

    internal static XINPUT_STATE MapState(Di.JoystickState s, bool invertY) =>
        MapRawState(s.X, s.Y, s.Z, s.RotationX, s.RotationY, s.RotationZ,
            s.Buttons, s.PointOfViewControllers, invertY);

    internal static XINPUT_STATE MapRawState(int axis1, int axis2, int axis3, int axis4, int axis5, int axis6,
        bool[]? buttons, int[]? pov, bool invertY)
    {
        // x360ce's map for this DualShock 4 uses Axis 1/2 for the left stick,
        // Axis 3/6 for the right stick, Axis 4/5 for L2/R2, and POV 1 for D-pad.
        short lx = ToShort(axis1);
        short ly = ToShort(invertY ? -(long)axis2 : axis2);
        short rx = ToShort(axis3);
        short ry = ToShort(invertY ? -(long)axis6 : axis6);
        byte lt = AxisToTrigger(axis4);
        byte rt = AxisToTrigger(axis5);

        bool[] b = buttons ?? Array.Empty<bool>();
        ushort mask = 0;
        // Physical DS4 button indices from the x360ce mapping visible in the
        // user's setup: X,A,B,Y,LB,RB,Back,Start,L3,R3 are buttons 1..6,9..12.
        if (Pressed(b, 0)) mask |= 0x4000; // X
        if (Pressed(b, 1)) mask |= 0x1000; // A / Cross
        if (Pressed(b, 2)) mask |= 0x2000; // B / Circle
        if (Pressed(b, 3)) mask |= 0x8000; // Y / Triangle
        if (Pressed(b, 4)) mask |= 0x0100; // LB
        if (Pressed(b, 5)) mask |= 0x0200; // RB
        if (Pressed(b, 8)) mask |= 0x0020; // Back / Share
        if (Pressed(b, 9)) mask |= 0x0010; // Start / Options
        if (Pressed(b, 10)) mask |= 0x0040; // L3
        if (Pressed(b, 11)) mask |= 0x0080; // R3
        mask |= PovToXInput(pov);

        return new XINPUT_STATE
        {
            dwPacketNumber = 0,
            Gamepad = new XINPUT_GAMEPAD
            {
                wButtons = mask,
                bLeftTrigger = lt,
                bRightTrigger = rt,
                sThumbLX = lx,
                sThumbLY = ly,
                sThumbRX = rx,
                sThumbRY = ry
            }
        };
    }

    private static bool Pressed(bool[] buttons, int index) =>
        index >= 0 && index < buttons.Length && buttons[index];

    private static short ToShort(long value)
    {
        if (value < short.MinValue) value = short.MinValue;
        else if (value > short.MaxValue) value = short.MaxValue;
        return (short)value;
    }

    private static byte AxisToTrigger(int value)
    {
        // All axes were set to [-32768, 32767], so a released trigger is 0
        // and a fully pressed trigger is 255.
        double normalized = (value - (double)short.MinValue) / 65535.0;
        if (normalized < 0) normalized = 0;
        else if (normalized > 1) normalized = 1;
        return (byte)Math.Round(normalized * byte.MaxValue, MidpointRounding.AwayFromZero);
    }

    private static ushort PovToXInput(int[]? pov)
    {
        if (pov == null || pov.Length == 0 || pov[0] < 0) return 0;
        int angle = pov[0] % 36000;
        int sector = ((angle + 2250) / 4500) % 8;
        return sector switch
        {
            0 => 0x0001, // up
            1 => 0x0001 | 0x0008, // up + right
            2 => 0x0008, // right
            3 => 0x0002 | 0x0008, // down + right
            4 => 0x0002, // down
            5 => 0x0002 | 0x0004, // down + left
            6 => 0x0004, // left
            7 => 0x0001 | 0x0004, // up + left
            _ => 0
        };
    }

    private void CloseJoystick()
    {
        try { _joystick?.Unacquire(); } catch { }
        try { _joystick?.Dispose(); } catch { }
        _joystick = null;
        _productName = null;
        _instanceName = null;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        CloseJoystick();
        _directInput.Dispose();
    }
}
