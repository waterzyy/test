// =====================================================================
//  CoopInputRouter  -  standalone gamepad -> UDP bridge for FiveM co-op
// =====================================================================
//  Reads either XInput slot 2 or a physical DirectInput gamepad (e.g. the
//  user's USB DualShock 4) at 125 Hz, then streams compact invariant JSON to
//  the local FXServer resource `coop_input` over 127.0.0.1 UDP.
//
//  No .NET runtime required on the target PC when published with:
//      dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
//
//  Why this exists: RAGE mutes hardware XInput in a window that does not
//  have Windows focus, so the second (backgrounded) FiveM window cannot
//  see the gamepad at all. Natives however keep running in the background
//  client, so the pad is read out-of-process and replayed through
//  SetControlNormal() / SetGameplayCamRelative*() inside the game thread.
//
//  The process never touches GTA V: no injection, no memory access, no
//  window messages. It only reads the OS gamepad API and writes UDP to
//  loopback.
// =====================================================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Linq;
using System.Threading;

namespace CoopInputRouter;

// ---------------------------------------------------------------------
//  CLI options
// ---------------------------------------------------------------------
internal sealed class Options
{
    public int Port = 30126;          // UDP port the FiveM resource listens on
    public string Host = "127.0.0.1"; // always loopback
    public int PreferredSlot = 1;     // XInput: dwUserIndex 1 == slot 2
    public bool AllowFallback = true; // XInput fallback when preferred slot is absent
    public bool UseDirectInput = false; // read physical HID joystick directly (no x360ce)
    public string DeviceMatch = "Wireless Controller"; // default DS4 DirectInput name
    public bool InvertDirectInputY = true; // standard DirectInput Y commonly increases down
    public int Hz = 125;              // send rate
    public bool Quiet = false;
    public bool SelfTest = false;
    public bool Diagnostics = false;
    public string[] DirectInputAxes = DirectInputSource.StandardAxes;

    public int IntervalMs => Math.Max(1, 1000 / Math.Max(1, Hz));

    public static Options Parse(string[] argv, out string? error)
    {
        error = null;
        var o = new Options();
        for (int i = 0; i < argv.Length; i++)
        {
            string a = argv[i];
            string? Next() => i + 1 < argv.Length ? argv[++i] : null;

            switch (a)
            {
                case "--port":
                    if (!int.TryParse(Next(), out o.Port) || o.Port < 1 || o.Port > 65535)
                    { error = "--port needs a value in 1..65535"; return o; }
                    break;
                case "--host":
                    o.Host = Next() ?? "127.0.0.1";
                    break;
                case "--slot":
                    if (!int.TryParse(Next(), out o.PreferredSlot) || o.PreferredSlot < 0 || o.PreferredSlot > 3)
                    { error = "--slot needs a value in 0..3"; return o; }
                    break;
                case "--hz":
                    if (!int.TryParse(Next(), out o.Hz) || o.Hz < 10 || o.Hz > 1000)
                    { error = "--hz needs a value in 10..1000"; return o; }
                    break;
                case "--diagnostics": o.Diagnostics = true; break;
                case "--axes":
                    o.DirectInputAxes = (Next() ?? "").Split(',');
                    if (o.DirectInputAxes.Length != 6 || o.DirectInputAxes.Any(a => !DirectInputSource.ValidAxis(a)) ||
                        o.DirectInputAxes.Distinct().Count() != 6)
                    { error = "--axes needs six distinct names for LX,LY,RX,RY,LT,RT (X,Y,Z,RotationX,RotationY,RotationZ)"; return o; }
                    break;
                case "--directinput": o.UseDirectInput = true; break;
                case "--device":
                    o.DeviceMatch = Next() ?? "";
                    break;
                case "--no-invert-dinput-y": o.InvertDirectInputY = false; break;
                case "--no-fallback": o.AllowFallback = false; break;
                case "--quiet":       o.Quiet = true; break;
                // Legacy aliases from older builds. The destination port is
                // intentionally bound by coop_input, so no port probe runs.
                case "--no-port-check":
                case "--force": break;
                case "--selftest":    o.SelfTest = true; break;
                case "-h":
                case "--help":
                    PrintHelp();
                    Environment.Exit(0);
                    break;
                default:
                    error = $"unknown argument: {a}";
                    return o;
            }
        }
        return o;
    }

    private static void PrintHelp()
    {
        Console.WriteLine(
@"CoopInputRouter - gamepad -> UDP bridge for FiveM local split-screen

Usage: CoopInputRouter.exe [options]

  --port <n>        UDP port of the coop_input resource   (default 30126)
  --host <addr>     destination address                   (default 127.0.0.1)
  --directinput     read the physical pad directly; no x360ce/XInput slots
  --diagnostics    print DirectInput raw axes and normalized packet every second
  --axes <list>    LX,LY,RX,RY,LT,RT names; default X,Y,Z,RotationZ,RotationX,RotationY
  --device <text>   DirectInput device name fragment      (default Wireless Controller)
  --no-invert-dinput-y  do not invert DS4 stick Y axes in DirectInput mode
  --slot <0..3>     XInput dwUserIndex to read            (default 1 = slot 2)
  --no-fallback     disable XInput slot-0 fallback
  --hz <10..1000>   send rate in packets/second           (default 125 = 8 ms)
  --quiet           only print warnings and errors
  --selftest        run the built-in verification suite and exit
  -h, --help        this text

IMPORTANT: the coop_input resource listens on UDP 30126. This router sends
packets to that listener using an ephemeral local port; it does not bind 30126.
Therefore 30126 being open in FXServer is expected. Keep the resource port
separate from the FXServer game endpoint (normally 30125).");
    }
}

// ---------------------------------------------------------------------
//  XInput interop
// ---------------------------------------------------------------------
[StructLayout(LayoutKind.Sequential)]
internal struct XINPUT_GAMEPAD
{
    public ushort wButtons;
    public byte bLeftTrigger;
    public byte bRightTrigger;
    public short sThumbLX;
    public short sThumbLY;
    public short sThumbRX;
    public short sThumbRY;
}

[StructLayout(LayoutKind.Sequential)]
internal struct XINPUT_STATE
{
    public uint dwPacketNumber;
    public XINPUT_GAMEPAD Gamepad;
}

/// <summary>Abstraction over XInputGetState so the logic can be unit-tested.</summary>
internal interface IXInputSource
{
    /// <summary>Returns true when a pad is connected on <paramref name="slot"/>.</summary>
    bool TryGetState(int slot, out XINPUT_STATE state);

    string InputDescription => "XInput";
    string DescribeSlot(int slot) => $"dwUserIndex {slot} (XInput slot {slot + 1})";
}

internal sealed class NativeXInput : IXInputSource
{
    private const int ERROR_SUCCESS = 0;
    private const int ERROR_DEVICE_NOT_CONNECTED = 1167; // 0x48F
    private readonly string _dll;

    [DllImport("xinput1_4.dll", EntryPoint = "XInputGetState", CallingConvention = CallingConvention.StdCall)]
    private static extern uint XInputGetState_14(uint dwUserIndex, ref XINPUT_STATE pState);

    [DllImport("xinput1_3.dll", EntryPoint = "XInputGetState", CallingConvention = CallingConvention.StdCall)]
    private static extern uint XInputGetState_13(uint dwUserIndex, ref XINPUT_STATE pState);

    public NativeXInput()
    {
        // xinput1_4.dll ships with Windows 8+; xinput1_3.dll is installed by the
        // DirectX runtime on older builds. Probe once so we fail loudly and early.
        var s = default(XINPUT_STATE);
        try { XInputGetState_14(0, ref s); _dll = "xinput1_4.dll"; return; }
        catch (DllNotFoundException) { }
        catch (EntryPointNotFoundException) { }
        catch (BadImageFormatException) { }

        try { XInputGetState_13(0, ref s); _dll = "xinput1_3.dll"; return; }
        catch (DllNotFoundException) { }
        catch (EntryPointNotFoundException) { }
        catch (BadImageFormatException) { }

        throw new PlatformNotSupportedException(
            "Neither xinput1_4.dll nor xinput1_3.dll could be loaded. Install the DirectX End-User Runtime.");
    }

    public string LibraryName => _dll;

    public bool TryGetState(int slot, out XINPUT_STATE state)
    {
        state = default;
        uint r = _dll == "xinput1_4.dll" ? XInputGetState_14((uint)slot, ref state)
                                        : XInputGetState_13((uint)slot, ref state);
        if (r == ERROR_SUCCESS) return true;
        if (r == ERROR_DEVICE_NOT_CONNECTED) return false;
        return false; // treat any other failure as "no data this tick"
    }
}

// ---------------------------------------------------------------------
//  The packet
// ---------------------------------------------------------------------
internal readonly struct PadPacket
{
    public readonly float LX, LY, RX, RY, LT, RT;
    public readonly int Buttons;

    public PadPacket(float lx, float ly, float rx, float ry, float lt, float rt, int buttons)
    { LX = lx; LY = ly; RX = rx; RY = ry; LT = lt; RT = rt; Buttons = buttons; }

    public static readonly PadPacket Zero = new(0, 0, 0, 0, 0, 0, 0);

    public bool IsZero => LX == 0f && LY == 0f && RX == 0f && RY == 0f && LT == 0f && RT == 0f && Buttons == 0;
}

internal static class PadMapping
{
    // Hardware dead zones - the official Microsoft values.
    public const short LeftThumbDeadZone = 7849;
    public const short RightThumbDeadZone = 8689;
    public const byte TriggerThreshold = 30;

    // XInput thumb range is -32768..32767.
    private const float ThumbRange = 32767f;
    private const float TriggerRange = 255f;

    public static float Clamp01(float v) => v < 0f ? 0f : (v > 1f ? 1f : v);

    public static float ClampSymmetric(float v) => v < -1f ? -1f : (v > 1f ? 1f : v);

    /// <summary>
    /// Circular dead zone + rescale, so the stick starts at exactly 0.0 at the
    /// edge of the dead zone and reaches 1.0 at full deflection (no jump).
    /// Result range is -1..1 on both axes.
    /// </summary>
    public static (float x, float y) NormalizeThumb(short rawX, short rawY, short deadZone)
    {
        float x = rawX, y = rawY;
        float mag = MathF.Sqrt(x * x + y * y);
        if (mag <= deadZone || mag < 1e-4f) return (0f, 0f);

        float rescaled = (mag - deadZone) / (ThumbRange - deadZone);
        if (rescaled > 1f) rescaled = 1f;
        float scale = rescaled / mag;
        return (RoundAxis(x * scale), RoundAxis(y * scale));
    }

    /// <summary>Analog trigger, 0..1, with the hardware threshold removed.</summary>
    public static float NormalizeTrigger(byte raw, byte threshold)
    {
        if (raw <= threshold) return 0f;
        return Clamp01(RoundAxis((raw - threshold) / (TriggerRange - threshold)));
    }

    /// <summary>Round to 3 decimals for a compact packet; kills float dust.</summary>
    private static float RoundAxis(float v)
    {
        if (float.IsNaN(v) || float.IsInfinity(v)) return 0f;
        v = MathF.Round(v, 3, MidpointRounding.AwayFromZero);
        if (MathF.Abs(v) < 0.0005f) v = 0f;
        // Never let rounding push a full deflection past the range.
        return v < -1f ? -1f : (v > 1f ? 1f : v);
    }

    /// <summary>
    /// Full conversion. Stick Y keeps the XInput convention (positive = stick up)
    /// because RAGE's INPUT_MOVE_UD / INPUT_VEH_MOVE_UD are also "up = forward".
    /// The camera is the only place that needs an inverted Y and the FiveM client
    /// does that inversion itself, so the wire format stays unambiguous.
    /// </summary>
    public static PadPacket FromRaw(in XINPUT_STATE state)
    {
        var g = state.Gamepad;
        var (lx, ly) = NormalizeThumb(g.sThumbLX, g.sThumbLY, LeftThumbDeadZone);
        var (rx, ry) = NormalizeThumb(g.sThumbRX, g.sThumbRY, RightThumbDeadZone);
        return new PadPacket(
            lx, ly, rx, ry,
            NormalizeTrigger(g.bLeftTrigger, TriggerThreshold),
            NormalizeTrigger(g.bRightTrigger, TriggerThreshold),
            g.wButtons);
    }
}

internal static class PacketSerializer
{
    private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    private static string F(float v)
    {
        if (float.IsNaN(v) || float.IsInfinity(v)) v = 0f;
        // Last line of defence: the receiver expects -1..1, so never emit
        // something it would have to reject.
        if (v < -1f) v = -1f;
        else if (v > 1f) v = 1f;
        return v.ToString("0.###", Inv);
    }

    /// <summary>Compact, invariant, ASCII-safe. Never locale dependent.</summary>
    public static string ToJson(in PadPacket p) =>
        "{\"lx\":" + F(p.LX) +
        ",\"ly\":" + F(p.LY) +
        ",\"rx\":" + F(p.RX) +
        ",\"ry\":" + F(p.RY) +
        ",\"lt\":" + F(p.LT) +
        ",\"rt\":" + F(p.RT) +
        ",\"buttons\":" + p.Buttons.ToString(Inv) + "}";

    public static byte[] ToBytes(in PadPacket p) => Encoding.ASCII.GetBytes(ToJson(in p));
}

// ---------------------------------------------------------------------
//  Router (poll + send loop)
// ---------------------------------------------------------------------
internal sealed class Router
{
    private readonly Options _opt;
    private readonly IXInputSource _x;
    private readonly TextWriter _log;
    private readonly UdpClient _udp;
    private readonly IPEndPoint _dest;

    public int ActiveSlot { get; private set; } = -1;
    public long PacketsSent { get; private set; }
    public bool ControllerConnected { get; private set; }
    private long _nextPollMs;

    public Router(Options opt, IXInputSource x, TextWriter log, UdpClient udp, IPEndPoint dest)
    {
        _opt = opt; _x = x; _log = log; _udp = udp; _dest = dest;
    }

    /// <summary>Production scheduler: fallback/disconnected pads respect the same send rate.</summary>
    public bool Poll(long nowMs)
    {
        if (nowMs < _nextPollMs) return false;
        _nextPollMs = nowMs + _opt.IntervalMs;
        return Tick();
    }

    /// <summary>One poll+send iteration. Returns true when a packet went out.</summary>
    public bool Tick()
    {
        if (!TryRead(out int slot, out XINPUT_STATE st))
        {
            if (ControllerConnected)
            {
                ControllerConnected = false;
                Log($"gamepad lost - sending a neutral packet");
                Send(PadPacket.Zero);
            }
            return false;
        }

        if (slot != ActiveSlot)
        {
            ActiveSlot = slot;
            ControllerConnected = true;
            Log($"gamepad found on {_x.DescribeSlot(slot)}");
        }
        else
        {
            ControllerConnected = true;
        }

        return Send(PadMapping.FromRaw(in st));
    }

    private bool TryRead(out int slot, out XINPUT_STATE state)
    {
        state = default;
        if (_x.TryGetState(_opt.PreferredSlot, out state)) { slot = _opt.PreferredSlot; return true; }
        if (_opt.AllowFallback)
        {
            int other = _opt.PreferredSlot == 0 ? 1 : 0;
            if (_x.TryGetState(other, out state)) { slot = other; return true; }
        }
        slot = -1;
        return false;
    }

    public bool Send(in PadPacket p)
    {
        try
        {
            byte[] buf = PacketSerializer.ToBytes(in p);
            _udp.Send(buf, buf.Length, _dest);
            PacketsSent++;
            return true;
        }
        catch (Exception ex)
        {
            Log($"send failed ({ex.GetType().Name}: {ex.Message}) - will retry");
            return false;
        }
    }

    private void Log(string msg)
    {
        if (!_opt.Quiet) _log.WriteLine($"[coop-router] {msg}");
        else _log.WriteLine($"[coop-router] WARN {msg}");
    }
}

// ---------------------------------------------------------------------
//  Entry point
// ---------------------------------------------------------------------
internal static class Program
{
    private static int Main(string[] argv)
    {
        // Belt and braces: the packet must stay valid JSON on a machine whose
        // locale uses ',' as the decimal separator (de-DE, ru-RU, fi-FI, ...).
        CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
        CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.InvariantCulture;

        Console.OutputEncoding = Encoding.UTF8;

        var opt = Options.Parse(argv, out string? parseError);
        if (parseError != null)
        {
            Console.Error.WriteLine($"error: {parseError}");
            Console.Error.WriteLine("run with --help for usage");
            return 2;
        }

        if (opt.SelfTest) return SelfTest.Run(opt.Quiet);

        if (opt.UseDirectInput && !OperatingSystem.IsWindows())
        {
            Console.Error.WriteLine("[coop-router] DirectInput mode is Windows-only; use a Windows PC with the DS4 connected by USB.");
            return 5;
        }

        UdpClient udp;
        IPEndPoint dest;
        try
        {
            dest = new IPEndPoint(IPAddress.Parse(opt.Host), opt.Port);
            udp = new UdpClient(AddressFamily.InterNetwork);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[coop-router] cannot open the UDP socket: {ex.Message}");
            return 4;
        }

        IXInputSource input;
        try
        {
            input = opt.UseDirectInput
                ? new DirectInputSource(opt.DeviceMatch, opt.PreferredSlot, opt.InvertDirectInputY, opt.DirectInputAxes, opt.Diagnostics)
                : new NativeXInput();
        }
        catch (Exception ex)
        {
            string api = opt.UseDirectInput ? "DirectInput" : "XInput";
            Console.Error.WriteLine($"[coop-router] {api} unavailable: {ex.Message}");
            return 5;
        }
        var inputLifetime = input as IDisposable;

        if (!opt.Quiet)
        {
            Console.WriteLine("===================================================================");
            Console.WriteLine(" CoopInputRouter  -  gamepad -> UDP bridge for FiveM split-screen");
            Console.WriteLine("===================================================================");
            Console.WriteLine($" input source   : {input.InputDescription}");
            if (input is NativeXInput xinput)
            {
                Console.WriteLine($" xinput library : {xinput.LibraryName}");
                Console.WriteLine($" reading slot   : dwUserIndex {opt.PreferredSlot}" +
                                  (opt.AllowFallback ? $"  (fallback to {(opt.PreferredSlot == 0 ? 1 : 0)})" : "  (no fallback)"));
            }
            else
            {
                Console.WriteLine(" reading source : physical DualShock 4 (x360ce is not required)");
            }
            Console.WriteLine($" sending to     : {dest} every {opt.IntervalMs} ms (~{opt.Hz} Hz)");
            Console.WriteLine($" dead zones     : L={PadMapping.LeftThumbDeadZone} R={PadMapping.RightThumbDeadZone} T={PadMapping.TriggerThreshold}");
            Console.WriteLine("-------------------------------------------------------------------");
            Console.WriteLine(" waiting for a gamepad ... (Ctrl+C to stop)");
        }

        var router = new Router(opt, input, Console.Out, udp, dest);

        int stopping = 0;
        Console.CancelKeyPress += (_, e) => { e.Cancel = true; Interlocked.Exchange(ref stopping, 1); };

        var clock = Stopwatch.StartNew();
        long lastReport = 0;
        bool warnedNoPad = false;

        try
        {
            while (Volatile.Read(ref stopping) == 0)
            {
                long now = clock.ElapsedMilliseconds;

                // Always probe the preferred slot first, but never flood the receiver
                // when using a fallback slot or waiting for reconnection.
                router.Poll(now);

                if (!opt.Quiet && now - lastReport >= 5000)
                {
                    lastReport = now;
                    Console.WriteLine(router.ControllerConnected
                        ? $" status: pad on {input.DescribeSlot(router.ActiveSlot)}, {router.PacketsSent} packets sent"
                        : opt.UseDirectInput
                            ? $" status: waiting for DirectInput device '{opt.DeviceMatch}'"
                            : " status: no gamepad connected (slot " + opt.PreferredSlot + " empty)");
                }

                if (!router.ControllerConnected && !warnedNoPad && clock.ElapsedMilliseconds > 3000)
                {
                    warnedNoPad = true;
                    Console.WriteLine(opt.UseDirectInput
                        ? "[coop-router] no DirectInput pad yet - keep x360ce closed and check the DS4 USB cable."
                        : "[coop-router] no gamepad detected yet - check x360ce / the USB connection.");
                }

                Thread.Sleep(1);
            }
        }
        finally
        {
            // Let the background player come to a clean stop instead of running
            // away with a stuck throttle.
            router.Send(PadPacket.Zero);
            udp.Close();
            inputLifetime?.Dispose();
            if (!opt.Quiet)
                Console.WriteLine($"[coop-router] stopped after {router.PacketsSent} packets.");
        }

        return 0;
    }
}

// ---------------------------------------------------------------------
//  Built-in verification suite (runs on any OS, no gamepad required)
// ---------------------------------------------------------------------
internal sealed class FakeXInput : IXInputSource
{
    public readonly Dictionary<int, XINPUT_STATE> Pads = new();
    public int Calls;

    public bool TryGetState(int slot, out XINPUT_STATE state)
    {
        Calls++;
        if (Pads.TryGetValue(slot, out state)) return true;
        state = default;
        return false;
    }
}

internal static class SelfTest
{
    private static int _failed;
    private static int _passed;

    public static int Run(bool quiet)
    {
        var log = quiet ? TextWriter.Null : Console.Out;
        log.WriteLine("CoopInputRouter self-test");
        log.WriteLine("-------------------------");

        ThumbDeadZone();
        DirectInputMapping();
        TriggerDeadZone();
        YAxisConvention();
        ButtonMask();
        JsonShape();
        JsonLocaleIndependence();
        JsonRoundTrip(log);
        SlotFallback(log);
        PollRate(log);
        NeutralPacketOnDisconnect(log);

        log.WriteLine("-------------------------");
        log.WriteLine($"passed: {_passed}   failed: {_failed}");
        Console.WriteLine(_failed == 0 ? "SELFTEST OK" : "SELFTEST FAILED");
        return _failed == 0 ? 0 : 1;
    }

    // -- assertions -----------------------------------------------------
    private static void Check(bool cond, string name, string detail = "")
    {
        if (cond) { _passed++; Console.WriteLine($"  ok   {name}"); }
        else { _failed++; Console.WriteLine($"  FAIL {name}  {detail}"); }
    }

    private static void Near(float actual, float expected, float tol, string name)
        => Check(MathF.Abs(actual - expected) <= tol, name, $"expected ~{expected}, got {actual}");

    private static XINPUT_STATE Raw(short lx, short ly, short rx, short ry, byte lt, byte rt, ushort btn)
    {
        var s = default(XINPUT_STATE);
        s.Gamepad.sThumbLX = lx; s.Gamepad.sThumbLY = ly;
        s.Gamepad.sThumbRX = rx; s.Gamepad.sThumbRY = ry;
        s.Gamepad.bLeftTrigger = lt; s.Gamepad.bRightTrigger = rt;
        s.Gamepad.wButtons = btn;
        return s;
    }

    // -- tests ----------------------------------------------------------
    private static void ThumbDeadZone()
    {
        var (x, y) = PadMapping.NormalizeThumb(7849, 0, PadMapping.LeftThumbDeadZone);
        Check(x == 0f && y == 0f, "left thumb inside dead zone (7849) -> 0.0");

        var (x2, y2) = PadMapping.NormalizeThumb(0, 0, PadMapping.LeftThumbDeadZone);
        Check(x2 == 0f && y2 == 0f, "centred stick -> 0.0");

        var (fx, fy) = PadMapping.NormalizeThumb(32767, 0, PadMapping.LeftThumbDeadZone);
        Check(fx == 1f && fy == 0f, "full right deflection -> +1.0");

        var (nx, ny) = PadMapping.NormalizeThumb(0, -32768, PadMapping.LeftThumbDeadZone);
        Check(nx == 0f && ny == -1f, "full down deflection -> -1.0", $"got ({nx};{ny})");

        var (mx, my) = PadMapping.NormalizeThumb(-32768, 0, PadMapping.LeftThumbDeadZone);
        Check(mx == -1f && my == 0f, "full left deflection -> -1.0 (negative axis is not clamped to 0)", $"got ({mx};{my})");

        var (qux, quy) = PadMapping.NormalizeThumb(-16384, -16384, PadMapping.LeftThumbDeadZone);
        Check(qux < 0f && quy < 0f, "down-left quadrant keeps both signs", $"got ({qux};{quy})");

        // Diagonal must not exceed the unit circle after rescale.
        var (dx, dy) = PadMapping.NormalizeThumb(23170, 23170, PadMapping.LeftThumbDeadZone);
        Check(MathF.Sqrt(dx * dx + dy * dy) <= 1.0001f, "diagonal magnitude <= 1.0");

        // Monotonic: a bigger push gives a bigger value, no step at the edge.
        var (a, _) = PadMapping.NormalizeThumb(16384, 0, PadMapping.LeftThumbDeadZone);
        var (b, _) = PadMapping.NormalizeThumb(24576, 0, PadMapping.LeftThumbDeadZone);
        Check(a > 0f && b > a, "rescale is monotonic and starts above 0", $"a={a} b={b}");

        var (rx0, ry0) = PadMapping.NormalizeThumb(8689, 0, PadMapping.RightThumbDeadZone);
        Check(rx0 == 0f && ry0 == 0f, "right thumb dead zone (8689) -> 0.0");

        var (rx1, _) = PadMapping.NormalizeThumb(8688, 0, PadMapping.RightThumbDeadZone);
        Check(rx1 == 0f, "right thumb 8688 (just under) -> 0.0");
    }

    private static void DirectInputMapping()
    {
        Check(DirectInputSource.NormalizeAxis(32767, 0, 65535) == -1,
            "unsigned driver center normalizes instead of saturating camera");
        Check(DirectInputSource.NormalizeAxis(65535, 0, 65535) == short.MaxValue,
            "unsigned driver maximum maps to signed maximum");
        Check(DirectInputSource.NormalizeAxis(0, 0, 65535) == short.MinValue,
            "unsigned released trigger maps to signed minimum");
        Check(DirectInputSource.NormalizeAxis(127, 0, 255) < 0 &&
            Math.Abs((int)DirectInputSource.NormalizeAxis(127, 0, 255)) < 130,
            "8-bit center stays in the stick deadzone");
        Check(DirectInputSource.NormalizeAxis(-12000, -32768, 32767) == -12000,
            "signed driver range preserves values");
        bool rejected = false;
        try { DirectInputSource.NormalizeAxis(65536, 0, 65535); }
        catch (ArgumentOutOfRangeException) { rejected = true; }
        Check(rejected, "out-of-range axis rejected instead of clamped into full throttle");
        rejected = false;
        try { DirectInputSource.NormalizeAxis(0, 1, 1); }
        catch (ArgumentException) { rejected = true; }
        Check(rejected, "invalid driver range rejected");
        var axesOption = Options.Parse(new[] { "--axes", "X,Y,Z,RotationZ,RotationX,RotationY" }, out var axesError);
        Check(axesError == null && axesOption.DirectInputAxes[3] == "RotationZ", "axis mapping option accepted");
        Options.Parse(new[] { "--axes", "X,X,Z,RotationZ,RotationX,RotationY" }, out axesError);
        Check(axesError != null, "duplicate mapped axes rejected");

        var buttons = new bool[12];
        buttons[0] = true;  // X
        buttons[1] = true;  // A
        buttons[4] = true;  // LB
        buttons[10] = true; // L3
        int[] pov = { 0, -1, -1, -1 }; // D-pad Up

        var mapped = DirectInputSource.MapRawState(
            short.MaxValue, short.MinValue, short.MinValue,
            short.MinValue, short.MaxValue, short.MaxValue,
            buttons, pov, invertY: true).Gamepad;
        Check(mapped.sThumbLX == short.MaxValue && mapped.sThumbLY == short.MaxValue,
            "DirectInput left stick maps X and inverted Y to XInput range");
        Check(mapped.sThumbRX == short.MinValue && mapped.sThumbRY == -short.MaxValue,
            "DirectInput right stick uses axes 3/6 with inverted Y");
        Check(mapped.bLeftTrigger == 0 && mapped.bRightTrigger == byte.MaxValue,
            "DirectInput triggers map released/full to 0/255");
        Check(mapped.wButtons == 0x5141,
            "DirectInput face/shoulder/L3 buttons and POV map to XInput bits",
            $"got 0x{mapped.wButtons:X4}");
    }

    private static void TriggerDeadZone()
    {
        Check(PadMapping.NormalizeTrigger(0, PadMapping.TriggerThreshold) == 0f, "trigger 0 -> 0.0");
        Check(PadMapping.NormalizeTrigger(30, PadMapping.TriggerThreshold) == 0f, "trigger 30 (threshold) -> 0.0");
        Check(PadMapping.NormalizeTrigger(255, PadMapping.TriggerThreshold) == 1f, "trigger 255 -> 1.0");
        Near(PadMapping.NormalizeTrigger(142, PadMapping.TriggerThreshold), 0.498f, 0.002f, "trigger 142 -> ~0.498");
        Check(PadMapping.NormalizeTrigger(255, PadMapping.TriggerThreshold) <= 1f, "trigger never exceeds 1.0");
    }

    private static void YAxisConvention()
    {
        var p = PadMapping.FromRaw(Raw(0, 32767, 0, 32767, 0, 0, 0));
        Check(p.LY == 1f, "stick pushed up -> ly = +1.0 (XInput/RAGE MoveUD convention)");
        Check(p.RY == 1f, "right stick up -> ry = +1.0 (client negates it for camera pitch)");

        var d = PadMapping.FromRaw(Raw(0, -32768, 0, -32768, 0, 0, 0));
        Check(d.LY == -1f && d.RY == -1f, "stick pushed down -> -1.0");
    }

    private static void ButtonMask()
    {
        ushort all = 0x3FFF; // A,B,X,Y,LS,RS,LB,RB,Back,Start,DPad x4
        var p = PadMapping.FromRaw(Raw(0, 0, 0, 0, 0, 0, all));
        Check(p.Buttons == 16383, "button mask passthrough (0x3FFF -> 16383)");

        var a = PadMapping.FromRaw(Raw(0, 0, 0, 0, 0, 0, 0x1000));
        Check(a.Buttons == 4096, "XInput X == 0x1000 == 4096");

        var lb = PadMapping.FromRaw(Raw(0, 0, 0, 0, 0, 0, 0x0100));
        Check(lb.Buttons == 256, "XInput LB == 0x0100 == 256");
    }

    private static void JsonShape()
    {
        string json = PacketSerializer.ToJson(PadPacket.Zero);
        Check(json == "{\"lx\":0,\"ly\":0,\"rx\":0,\"ry\":0,\"lt\":0,\"rt\":0,\"buttons\":0}",
              "neutral packet serialises exactly as specified", json);

        string j2 = PacketSerializer.ToJson(new PadPacket(0.5f, -1f, 0.123f, 0f, 1f, 0.498f, 4096));
        Check(j2 == "{\"lx\":0.5,\"ly\":-1,\"rx\":0.123,\"ry\":0,\"lt\":1,\"rt\":0.498,\"buttons\":4096}",
              "mixed values serialise compactly with '.' separators", j2);

        string j3 = PacketSerializer.ToJson(new PadPacket(float.NaN, float.PositiveInfinity, 2f, -9f, 0, 0, 0));
        Check(j3.Contains("\"lx\":0") && j3.Contains("\"ly\":0") && j3.Contains("\"rx\":1") && j3.Contains("\"ry\":-1"),
              "NaN/Inf/out-of-range floats are sanitised, never emitted raw", j3);

        // The mapping itself must never produce anything outside -1..1.
        var full = PadMapping.FromRaw(Raw(-32768, -32768, -32768, -32768, 255, 255, 0));
        Check(full.LX >= -1f && full.LX <= 1f && full.LY >= -1f && full.LY <= 1f
           && full.RX >= -1f && full.RX <= 1f && full.RY >= -1f && full.RY <= 1f
           && full.LT >= 0f && full.LT <= 1f && full.RT >= 0f && full.RT <= 1f,
              "FromRaw output always stays inside the documented range",
              $"lx={full.LX} ly={full.LY} rx={full.RX} ry={full.RY} lt={full.LT} rt={full.RT}");
    }

    private static void JsonLocaleIndependence()
    {
        var previous = Thread.CurrentThread.CurrentCulture;
        try
        {
            foreach (var name in new[] { "fr-FR", "de-DE", "fi-FI", "ru-RU" })
            {
                var ci = CultureInfo.GetCultureInfo(name);
                Thread.CurrentThread.CurrentCulture = ci;
                CultureInfo.DefaultThreadCurrentCulture = ci;
                string json = PacketSerializer.ToJson(new PadPacket(0.25f, -0.75f, 0.5f, -0.5f, 0.125f, 0.875f, 0));
                bool dots = json.Contains("0.25") && json.Contains("-0.75") && json.Contains("0.125")
                            && json.Contains("-0.5") && json.Contains("0.875");
                // A locale decimal separator would show up as e.g. "0,25".
                bool commaDecimal = System.Text.RegularExpressions.Regex.IsMatch(json, @"[0-9],[0-9]");
                Check(dots && !commaDecimal, $"invariant JSON under {name} culture", json);
            }
        }
        finally
        {
            Thread.CurrentThread.CurrentCulture = previous;
            CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
        }
    }

    private static void JsonRoundTrip(TextWriter log)
    {
        // Real socket round trip: serialise -> UDP loopback -> parse back.
        int port = GetFreePort();
        using var rx = new UdpClient(AddressFamily.InterNetwork);
        rx.Client.ReceiveTimeout = 2000;
        rx.Client.Bind(new IPEndPoint(IPAddress.Loopback, port));

        using var tx = new UdpClient(AddressFamily.InterNetwork);
        var dest = new IPEndPoint(IPAddress.Loopback, port);

        var pkt = new PadPacket(0.875f, -0.5f, 0.25f, -1f, 0.5f, 1f, 0x1000 | 0x0010);
        byte[] buf = PacketSerializer.ToBytes(in pkt);
        tx.Send(buf, buf.Length, dest);

        var ep = new IPEndPoint(IPAddress.Any, 0);
        byte[] got = rx.Receive(ref ep);
        string text = Encoding.ASCII.GetString(got);
        log.WriteLine($"  loopback payload: {text}");

        var parsed = MiniJson.Parse(text);
        Check(parsed != null, "loopback payload parses as JSON");
        if (parsed == null) return;
        Near(parsed["lx"], 0.875f, 0.0001f, "loopback lx");
        Near(parsed["ly"], -0.5f, 0.0001f, "loopback ly");
        Near(parsed["rx"], 0.25f, 0.0001f, "loopback rx");
        Near(parsed["ry"], -1f, 0.0001f, "loopback ry");
        Near(parsed["lt"], 0.5f, 0.0001f, "loopback lt");
        Near(parsed["rt"], 1f, 0.0001f, "loopback rt");
        Check((int)parsed["buttons"] == 0x1010, "loopback buttons", parsed["buttons"].ToString());
        Check(got.Length < 90, "packet stays compact (< 90 bytes)", $"{got.Length} bytes");
    }

    private static void SlotFallback(TextWriter log)
    {
        var opt = new Options { Port = GetFreePort(), PreferredSlot = 1, Hz = 500, Quiet = true };
        var fake = new FakeXInput();
        fake.Pads[0] = Raw(32767, 0, 0, 0, 0, 0, 0x1000); // only slot 0 answers

        using var rx = new UdpClient(AddressFamily.InterNetwork);
        rx.Client.ReceiveTimeout = 1500;
        rx.Client.Bind(new IPEndPoint(IPAddress.Loopback, opt.Port));

        using var tx = new UdpClient(AddressFamily.InterNetwork);
        var dest = new IPEndPoint(IPAddress.Loopback, opt.Port);
        var router = new Router(opt, fake, TextWriter.Null, tx, dest);

        for (long now = 0; now < 250; now++) router.Poll(now);

        Check(router.ActiveSlot == 0, "falls back to dwUserIndex 0 when slot 1 is empty", $"slot={router.ActiveSlot}");
        Check(router.PacketsSent > 10, "keeps streaming while on the fallback slot", $"n={router.PacketsSent}");

        var ep = new IPEndPoint(IPAddress.Any, 0);
        byte[] got = rx.Receive(ref ep);
        var parsed = MiniJson.Parse(Encoding.ASCII.GetString(got));
        Check(parsed != null && MathF.Abs(parsed["lx"] - 1f) < 0.001f, "fallback slot data reaches the receiver");
        log.WriteLine($"  fallback packets sent: {router.PacketsSent}");
    }

    private static void PollRate(TextWriter log)
    {
        var opt = new Options { PreferredSlot = 1, Hz = 60, Quiet = true };
        var fake = new FakeXInput();
        fake.Pads[0] = Raw(0, 0, 0, 0, 0, 0, 0);
        using var rx = new UdpClient(new IPEndPoint(IPAddress.Loopback, 0));
        using var tx = new UdpClient(AddressFamily.InterNetwork);
        var router = new Router(opt, fake, TextWriter.Null, tx, (IPEndPoint)rx.Client.LocalEndPoint!);
        for (long now = 0; now < 1000; now++) router.Poll(now);
        long expected = (1000 + opt.IntervalMs - 1) / opt.IntervalMs;
        Check(router.PacketsSent == expected, "fallback sends at configured interval instead of every millisecond",
            $"expected={expected}, sent={router.PacketsSent}");
        Check(fake.Calls == expected * 2, "fallback polling itself is rate-limited");
        fake.Pads.Clear();
        int before = fake.Calls;
        for (long now = 1000; now < 2000; now++) router.Poll(now);
        Check(fake.Calls - before <= expected * 2, "disconnected polling is also rate-limited");
        log.WriteLine($"  rate-limited fallback: {expected} packets per simulated second at {opt.Hz} Hz setting");
    }

    private static void NeutralPacketOnDisconnect(TextWriter log)
    {
        var opt = new Options { Port = GetFreePort(), PreferredSlot = 1, Quiet = true };
        var fake = new FakeXInput();
        fake.Pads[1] = Raw(0, 0, 0, 0, 0, 255, 0x1000);

        using var rx = new UdpClient(AddressFamily.InterNetwork);
        rx.Client.ReceiveTimeout = 1500;
        rx.Client.Bind(new IPEndPoint(IPAddress.Loopback, opt.Port));

        using var tx = new UdpClient(AddressFamily.InterNetwork);
        var dest = new IPEndPoint(IPAddress.Loopback, opt.Port);
        var router = new Router(opt, fake, TextWriter.Null, tx, dest);

        router.Tick(); // connected, RT pressed
        fake.Pads.Clear(); // yank the pad
        router.Tick(); // must emit one neutral packet

        var ep = new IPEndPoint(IPAddress.Any, 0);
        rx.Receive(ref ep); // discard the first
        byte[] second = rx.Receive(ref ep);
        string text = Encoding.ASCII.GetString(second);
        log.WriteLine($"  disconnect payload: {text}");
        Check(text == "{\"lx\":0,\"ly\":0,\"rx\":0,\"ry\":0,\"lt\":0,\"rt\":0,\"buttons\":0}",
              "a lost pad sends exactly one neutral packet");
    }

    private static int GetFreePort()
    {
        // TCP and UDP have separate port namespaces; reserve the protocol we test.
        using var socket = new UdpClient(new IPEndPoint(IPAddress.Loopback, 0));
        return ((IPEndPoint)socket.Client.LocalEndPoint!).Port;
    }
}

/// <summary>
/// Tiny tolerant reader for the bridge's own packets. Used by the self-test to
/// verify what actually went over the wire - no external dependencies.
/// </summary>
internal static class MiniJson
{
    public static Dictionary<string, float>? Parse(string json)
    {
        var result = new Dictionary<string, float>();
        if (string.IsNullOrWhiteSpace(json)) return null;
        json = json.Trim();
        if (json[0] != '{' || json[^1] != '}') return null;
        json = json[1..^1];

        foreach (string rawPart in json.Split(','))
        {
            int colon = rawPart.IndexOf(':');
            if (colon < 0) return null;
            string key = rawPart[..colon].Trim().Trim('"');
            string val = rawPart[(colon + 1)..].Trim();
            if (!float.TryParse(val, NumberStyles.Float, CultureInfo.InvariantCulture, out float f))
                return null;
            result[key] = f;
        }
        return result.Count == 7 ? result : null;
    }
}
