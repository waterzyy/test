local function run()
-- Runs in Lua 5.3+ (or fengari); FiveM calls are simulated.
local events, commands, threads, controls, localEvents = {}, {}, {}, {}, {}
local now, veh, driver = 100, false, false
local fighting, paused, dead, weapon, staminaRestores = false, false, false, "WEAPON_UNARMED", 0
local camHeading, camPitch, camWrites = 0, 0, 0
local entityHeading, bodyWrites, worldYaw = 0, 0, 0
local vehicleSpeed, vehicleId, lockStatus, lockedForPlayer, seated = 0, 100, 1, false, true
local disabled, leaves, meleeTarget = {}, {}, 0
function GetGameTimer() return now end
function GetConvar(_, default) return default end
function TriggerEvent(name) localEvents[#localEvents+1]=name end
function GetHashKey(s) return s end
function GetPlayerServerId() return 2 end
function PlayerId() return 1 end
function PlayerPedId() return 42 end
function GetFrameTime() return 1/60 end
function IsEntityDead() return dead end
function IsPauseMenuActive() return paused end
function IsPedInAnyVehicle() return veh end
function GetVehiclePedIsIn() return veh and vehicleId or 0 end
function GetPedInVehicleSeat() return driver and 42 or 7 end
function GetCurrentPedWeapon() return true, weapon end
function GetWeapontypeGroup(w) return w=='WEAPON_BAT' and 'GROUP_MELEE' or 'GROUP_PISTOL' end
function IsPedInMeleeCombat() return fighting end
function GetMeleeTargetForPed() return meleeTarget end
function GetGameplayCamRot() return {x=camPitch,y=0,z=worldYaw} end
function GetEntityHeading() return entityHeading end
function SetEntityHeading(_, v) entityHeading=v; bodyWrites=bodyWrites+1; worldYaw=v end
function GetEntitySpeed() return vehicleSpeed end
function GetVehicleDoorLockStatus() return lockStatus end
function GetVehicleDoorsLockedForPlayer() return lockedForPlayer end
function IsControlEnabled(_, id) return not disabled[id] end
function IsPedSittingInVehicle() return veh and seated end
function TaskLeaveVehicle(p, v, f) leaves[#leaves+1]={ped=p,vehicle=v,flags=f} end
function RestorePlayerStamina() staminaRestores=staminaRestores+1 end
function HasPedGotWeapon() return false end
function SetControlNormal(_, id, value) controls[id] = value; return true end
function SetGameplayCamRelativeHeading(v) camHeading=v;camWrites=camWrites+1 end
function SetGameplayCamRelativePitch(v) camPitch=v;camWrites=camWrites+1 end
function GetGameplayCamRelativeHeading() return camHeading end
function GetGameplayCamRelativePitch() return camPitch end
function RegisterNetEvent(n, fn) events[n] = fn end
function RegisterCommand(n, fn) commands[n] = fn end
function AddEventHandler() end
Citizen = {CreateThread=function(fn) threads[#threads+1] = coroutine.create(fn) end,
Wait=function() coroutine.yield() end}
assert(loadfile('coop_input/client.lua'))()
commands.coop_debug()
local co = threads[#threads]
assert(coroutine.resume(co))
local function tick(t)
    now = t; controls = {}
    local ok, err = coroutine.resume(co); assert(ok, err)
end
local function packet(p)
    local d = {lx=0,ly=0,rx=0,ry=0,lt=0,rt=0,buttons=0}
    for k,v in pairs(p or {}) do d[k]=v end
    events['coop_input:updateState'](d)
end
local function arm(t)
    now=t;packet();now=t+210;packet();tick(now)
end
local passed=0
local function check(ok, label) assert(ok, label);passed=passed+1;print('PASS '..label) end
-- Ignore input before role selection.
packet({rt=1});tick(110);check(next(controls)==nil,'inactive client receives no injected controls')
events['coop_input:setRole'](2,2)
now=120;packet({ry=1,rt=1});tick(120)
check(next(controls)==nil,'held/wrong startup axes cannot arm')
arm(130)
now=350;packet({ry=0.8});tick(350)
check(controls[2] and controls[2]<0,'right stick reaches native camera axis')
now=360;packet();tick(360)
check(controls[2]==0,'released camera stops immediately')
now=370;packet({ry=0.8});tick(370);tick(900)
check(next(controls)==nil,'camera-only stale packet stops input')
now=910;packet({rt=1});tick(910)
check(next(controls)==nil,'reconnection requires neutral state')
arm(920);veh=true;driver=true
now=1140;packet({rt=0.8,lt=0,lx=0.5});tick(1140)
check(controls[71]==1 and controls[72]==0 and controls[59]>0,'driver gas brake and steering')
check(controls[60]==nil,'walking axis not injected into vehicle pitch')
now=1150;packet({rt=0.8,buttons=0x100});tick(1150)
check(controls[69]==0,'gas does not fire weapon while aiming')
check(controls[76]==0,'R1 does not engage handbrake')
driver=false;tick(1160)
check(controls[71]==nil and controls[59]==nil,'passenger cannot inject steering or gas')
veh=false
now=1170;events['coop_input:updateState']({lx=0});tick(1170)
check(next(controls)==nil,'partial packet fails closed')
arm(1180)
now=1400;packet({ry=0/0});tick(1400)
check(next(controls)==nil,'NaN packet fails closed')
arm(1410)
now=1630;packet({buttons=0x20});packet();tick(1630)
check(controls[0]==1,'short camera-switch press survives between frames')
tick(1640);check(controls[0]==nil,'camera-switch edge applied once')
commands.coop_profile(nil,{'ds4_unsigned'})
now=1700;packet({lx=.5,ly=.5,rx=.5,ry=.5});now=1910;packet({lx=.5,ly=.5,rx=.5,ry=.5});tick(1910)
check(controls[1]==0 and controls[2]==0,'unsigned DS4 sticks center at 0.5')
commands.coop_profile(nil,{'signed_triggers'})
now=2000;packet({lt=-1,rt=-1});now=2210;packet({lt=-1,rt=-1});tick(2210)
veh=true;driver=true;now=2220;packet({lt=-1,rt=1});tick(2220)
check(controls[71]==1 and controls[72]==0,'signed trigger profile maps released and pressed')
veh=false
commands.coop_profile(nil,{'xinput'});arm(2300)
commands.coop_camera(nil,{'manual'});camWrites=0
now=2520;packet({rx=0.8,ry=0.8});tick(2520)
check(camWrites==2 and controls[1]==nil and controls[2]==nil,'manual camera never also injects LOOK axes')
camWrites=0;now=2530;packet();tick(2530)
check(camWrites==0,'manual camera stops on neutral')
commands.coop_camera(nil,{'native'});camWrites=0
now=2540;packet({rx=0.8});tick(2540)
check(camWrites==0 and controls[1]>0,'native camera never manually rotates')
now=2550;packet({buttons=0x8000});packet();tick(2550)
check(controls[23]==1,'short enter-vehicle tap survives packet release before frame')
-- Digital pedals, hysteresis and context changes.
commands.coop_profile(nil,{'xinput'});arm(3000);veh=true;driver=true
now=3220;packet({rt=0.1});tick(now)
check(controls[71]==1,'light R2 press supplies 100 percent gas')
now=3230;packet({rt=1,lt=0.1});tick(now)
check(controls[71]==0 and controls[72]==1,'brake has priority over simultaneous gas')
now=3240;packet({rt=0.03});tick(now)
check(controls[71]==1 and controls[72]==0,'trigger hysteresis prevents flicker while held')
now=3250;packet({rt=0.01});tick(now)
check(controls[71]==0,'released trigger supplies zero gas')
now=3260;packet({rt=0.03});tick(now)
check(controls[71]==0,'below press threshold cannot restart gas')
now=3270;packet({lt=0.06});tick(now)
check(controls[72]==1,'light L2 press supplies full brake')
now=3280;packet({lx=0.85});tick(now)
check(controls[59]==1,'worn stick reaches full steering without nonlinear slowdown')
now=3290;packet();tick(now)
check(controls[59]==0 and controls[71]==0 and controls[72]==0,'centered car input is immediately neutral')
commands.coop_pedals(nil,{'analog'})
now=3300;packet({rt=0.4});tick(now)
check(controls[71]==0.4,'analog pedals remain available explicitly')
commands.coop_pedals(nil,{'digital'})
now=3310;packet({rt=0.4});tick(now)
check(controls[71]==1,'digital mode restores full throttle')
now=3320;packet({rt=0.7});tick(now);tick(3900)
check(next(controls)==nil,'stale held gas is not replayed')
now=3910;packet({rt=1});tick(now)
check(next(controls)==nil,'held gas cannot auto-arm after connection loss')
arm(3920);driver=false
now=4140;packet({rt=1,buttons=0x300});tick(now)
check(controls[71]==nil and controls[72]==nil and controls[91]==1 and controls[92]==1,'passenger uses passenger attack controls without gas or brake')

-- Melee: use the official 140/141/142/143 actions, never jump/run/reload together.
veh=false;weapon='WEAPON_UNARMED';fighting=true
now=4200;packet({lt=1,buttons=0x2000});tick(now)
check(controls[140]==1 and controls[45]==0,'circle punches instead of reloading during lock-on')
now=4210;packet({lt=1,buttons=0x4000});tick(now)
check(controls[143]==1 and controls[22]==1 and controls[25]==1,'square sends block and shared Space action with targeting in melee')
now=4220;packet({lt=1,buttons=0x1000});tick(now)
check(controls[141]==1 and controls[21]==0,'cross heavy attack does not also sprint')
now=4230;packet({lt=1,rt=1});tick(now)
check(controls[142]==1 and controls[24]==0,'unarmed R2 uses one alternate melee action')
now=4240;packet({lt=1,rt=1,buttons=0x5000});tick(now)
check(controls[143]==1 and controls[140]==0 and controls[141]==0 and controls[142]==0,'block suppresses conflicting attacks')
now=4250;packet({lt=1,rt=1,buttons=0x100});tick(now)
check(controls[24]==0 and controls[140]==0 and controls[141]==0 and controls[142]==0,'weapon wheel suppresses attack actions')
fighting=false;weapon='WEAPON_BAT'
now=4260;packet({buttons=0x2000});tick(now)
check(controls[140]==1 and controls[45]==0,'melee weapon is not treated as a firearm')
weapon='WEAPON_PISTOL'
now=4270;packet({buttons=0x2000});tick(now)
check(controls[45]==1 and controls[140]==0,'firearm circle reloads without a punch')
now=4280;packet({lt=1,rt=0.2});tick(now)
check(controls[24]==1 and controls[25]==1 and controls[142]==0,'firearm trigger sends full attack and aim without duplicate melee')
now=4290;packet({buttons=0x4000});tick(now)
check(controls[22]==1 and controls[143]==0,'square jumps outside a fighting stance')

-- Holding a punch should create new presses, not leave one stuck attack.
weapon='WEAPON_UNARMED';fighting=true
local meleeTime=4400
for _,fps in ipairs({30,60,144}) do
    local on,off=0,0
    for i=0,math.ceil(fps*0.65) do
        now=meleeTime+math.floor(i*1000/fps);packet({lt=1,buttons=0x2000});tick(now)
        if controls[140]==1 then on=on+1 else off=off+1 end
    end
    check(on>0 and off>0,('held melee produces new presses at %d FPS'):format(fps))
    meleeTime=now+100
end

-- Held sprint is implemented per frame, independent of UDP packet frequency/FPS.
weapon='WEAPON_UNARMED';fighting=false
arm(meleeTime+1300)
local t=meleeTime+1600
for _,fps in ipairs({30,60,144}) do
    commands.coop_sprint(nil,{'repeat'})
    local on,off,up=0,0,true
    for i=0,math.ceil(fps*0.65) do
        now=t+math.floor(i*1000/fps);packet({ly=0.45,buttons=0x1000});tick(now)
        if controls[21]==1 then on=on+1 else off=off+1 end
        up=up and math.abs(controls[31]+1)<0.001 and controls[141]==0
    end
    check(on>0 and off>0 and up,('held sprint creates press/release at %d FPS with full movement'):format(fps))
    now=now+1;packet();tick(now)
    check(controls[21]==0 and controls[31]==0,('sprint stops immediately on release at %d FPS'):format(fps))
    t=now+100
end
now=t;packet({buttons=0x1000});tick(now)
check(controls[21]==0,'cross does not sprint from a stationary stick')
now=t+10;packet({ly=1,lt=1,buttons=0x1000});tick(now)
check(controls[21]==0 and controls[141]==1,'lock-on switches cross from sprint to heavy attack')
now=t+20;packet({ly=1,buttons=0x1100});tick(now)
check(controls[21]==0,'weapon wheel suppresses sprint')
now=t+30;packet({ly=1,buttons=0x3000});tick(now)
check(controls[21]==0 and controls[140]==1,'punch and sprint are mutually exclusive')
commands.coop_profile(nil,{'xinput'});arm(t+40);t=t+250
commands.coop_sprint(nil,{'hold'})
now=t+40;packet({ly=1,buttons=0x1000});tick(now)
now=t+160;packet({ly=1,buttons=0x1000});tick(now)
check(controls[21]==1,'native hold sprint remains available')
check(staminaRestores==0,'normal stamina is preserved by default')
commands.coop_stamina(nil,{'on'})
now=t+170;packet({ly=1,buttons=0x1000});tick(now)
check(staminaRestores==1,'unlimited stamina requires explicit enabling')
commands.coop_stamina(nil,{'off'})
veh=true;driver=true
now=t+180;packet({rt=1,buttons=0x1000});tick(now)
check(controls[21]==nil and controls[141]==nil,'sprint and melee do not leak into vehicle controls')
veh=false;paused=true;tick(t+190)
check(next(controls)==nil,'pause clears all injected controls')
paused=false;now=t+200;packet({ly=1,buttons=0x1000});tick(now)
check(next(controls)==nil,'leaving pause with held controls requires neutral')
arm(t+210)
dead=true;tick(t+430)
check(next(controls)==nil,'death stops injected controls')
dead=false;arm(t+440)
now=t+660;packet({ly=1,buttons=0x1000});tick(now);tick(t+1200)
check(next(controls)==nil,'packet timeout cancels sprint repeat')
arm(t+1210)
-- Aim: default auto route, manual body yaw, scaled axes and analog strafing.
local base=now+100
commands.coop_profile(nil,{'xinput'});arm(base)
veh=false;fighting=false;weapon='WEAPON_PISTOL';meleeTarget=0
commands.coop_camera(nil,{'manual'});bodyWrites=0;camWrites=0
now=base+220;packet({lt=1,rx=0.6,ry=0.5,lx=0.4,ly=0.6});tick(now)
check(bodyWrites==1 and camWrites==1,'manual aim rotates ped yaw and camera pitch instead of ignored relative yaw')
check(controls[1]==nil and controls[290]==nil,'manual aim never simultaneously injects native look')
check(controls[30]>0 and controls[31]<0 and controls[30]<1 and controls[31]>-1 and controls[21]==0,
    'aim keeps partial diagonal strafing without sprint normalization')
check(controls[32]>0 and controls[33]==0 and controls[34]==0 and controls[35]>0,
    'aim forwards W and D directional actions in addition to stick axes')
bodyWrites=0;camWrites=0
now=base+230;packet({lt=1});tick(now)
check(bodyWrites==0 and camWrites==0 and controls[32]==0 and controls[35]==0,'released aim sticks stop both rotation and movement')
now=base+240;packet({lt=1,lx=-0.5,ly=-0.3});tick(now)
check(controls[33]>0 and controls[34]>0 and controls[32]==0 and controls[35]==0,'aim can strafe left and move backward')
bodyWrites=0;camWrites=0
now=base+250;packet({rx=0.6});tick(now)
check(bodyWrites==0 and camWrites==1,'releasing aim returns to ordinary manual look without rotating ped')
commands.coop_camera(nil,{'native'});commands.coop_aim(nil,{'auto'});bodyWrites=0;camWrites=0
now=base+260;packet({lt=1,rx=0.6});tick(now)
check(controls[1]>0 and controls[290]>0 and bodyWrites==0,'auto aim initially uses regular and scaled native look controls')
now=base+340;packet({lt=1,rx=0.6});tick(now)
check(bodyWrites==0,'auto aim waits for a meaningful frozen-camera interval')
bodyWrites=0;now=base+460;packet({lt=1,rx=0.6});tick(now)
check(bodyWrites==1 and controls[1]==nil and controls[290]==nil,'frozen native aim switches to exclusive manual body rotation')
bodyWrites=0;now=base+480;packet({lt=1,rx=0.6});tick(now)
check(bodyWrites==1 and controls[1]==nil,'aim fallback stays stable until aim is released')
now=base+490;packet();tick(now)
bodyWrites=0;now=base+500;packet({lt=1,rx=0.6});tick(now)
check(bodyWrites==0 and controls[290]>0,'new aim session retries native controls')
commands.coop_aim(nil,{'native'});bodyWrites=0
now=base+700;packet({lt=1,rx=0.6});tick(now)
now=base+900;packet({lt=1,rx=0.6});tick(now)
check(bodyWrites==0 and controls[290]>0,'explicit native aim never forces a body rotation')
commands.coop_aim(nil,{'auto'});bodyWrites=0
for i=0,4 do
    worldYaw=30+i*0.3;now=base+910+i*100;packet({lt=1,rx=0.6});tick(now)
end
check(bodyWrites==0 and controls[290]>0,'responsive aim camera does not trigger manual fallback')
commands.coop_aim(nil,{'manual'});commands.coop_camera(nil,{'native'});bodyWrites=0
now=base+1320;packet({lt=1,rx=0.6});tick(now)
check(bodyWrites==1 and controls[1]==nil,'manual aim works independently of ordinary native camera setting')
commands.coop_aim(nil,{'auto'});now=base+1330;packet();tick(now)

-- Exit at rest: shared F/Y actions plus a one-shot normal, animated fallback.
veh=true;driver=true;seated=true;vehicleSpeed=0;lockStatus=1;lockedForPlayer=false;disabled={};leaves={}
local ex=base+1400
now=ex;packet({buttons=0x8000});tick(now)
check(controls[23]==1 and controls[75]==1 and #leaves==0,'triangle sends both stationary Enter and VehicleExit actions')
now=ex+10;packet();tick(now)
now=ex+290;packet();tick(now)
check(#leaves==0,'normal native exit gets time to start before fallback')
now=ex+310;packet();tick(now)
check(#leaves==1 and leaves[1].ped==42 and leaves[1].vehicle==vehicleId and leaves[1].flags==0,
    'stopped vehicle fallback requests one normal exit with flag zero')
now=ex+500;packet();tick(now)
check(#leaves==1,'released triangle does not repeat exit task')
-- Hold one press for over a second: never recreate the task each frame.
now=ex+510;packet({buttons=0x8000});tick(now)
for i=1,5 do now=ex+510+i*200;packet({buttons=0x8000});tick(now) end
check(#leaves==2,'holding triangle produces only one additional exit task')
now=now+10;packet();tick(now)
-- A passenger should get the same reliable stopped-car exit.
driver=false;local stamp=now+10
now=stamp;packet({buttons=0x8000});tick(now)
now=stamp+310;packet();tick(now)
check(#leaves==3,'stationary passenger also receives normal exit fallback')
-- Do not interfere if the game already started the exit animation.
local before=#leaves;stamp=now+10;seated=true
now=stamp;packet({buttons=0x8000});tick(now)
seated=false;now=stamp+310;packet();tick(now)
check(#leaves==before,'an exit already in progress is not restarted')
seated=true
-- Moving exits remain native; no scripted bail-out or teleport.
stamp=now+10;vehicleSpeed=8
now=stamp;packet({buttons=0x8000});tick(now)
now=stamp+310;packet();tick(now)
check(#leaves==before,'moving vehicle does not receive scripted exit task')
vehicleSpeed=0
local function rejectedExit(label)
    local n=#leaves;local started=now+10
    now=started;packet({buttons=0x8000});tick(now)
    now=started+310;packet();tick(now)
    check(#leaves==n,label)
end
lockStatus=2;rejectedExit('exit fallback does not unlock or bypass locked doors');lockStatus=1
lockedForPlayer=true;rejectedExit('exit fallback respects player-specific door locks');lockedForPlayer=false
disabled[75]=true;rejectedExit('exit fallback respects disabled VehicleExit control');disabled[75]=nil
disabled[23]=true;rejectedExit('exit fallback respects disabled Enter control');disabled[23]=nil
-- Starting to drive or changing the car cancels the queued fallback.
stamp=now+10;now=stamp;packet({buttons=0x8000});tick(now)
vehicleSpeed=4;now=stamp+310;packet();tick(now)
check(#leaves==before,'acceleration before fallback prevents scripted moving exit');vehicleSpeed=0
stamp=now+10;now=stamp;packet({buttons=0x8000});tick(now)
vehicleId=101;now=stamp+310;packet();tick(now)
check(#leaves==before,'queued exit cannot act on another vehicle');vehicleId=100
stamp=now+10;now=stamp;packet({buttons=0x8000});tick(now)
paused=true;tick(stamp+10);paused=false;arm(stamp+20)
now=stamp+330;packet();tick(now)
check(#leaves==before,'pause cancels queued exit before task is dispatched')

-- Guard establishes targeting and survives transient loss of the engine combat flag.
veh=false;weapon='WEAPON_UNARMED';fighting=true;meleeTarget=0
stamp=now+10;now=stamp;packet({buttons=0x4000});tick(now)
check(controls[143]==1 and controls[25]==1 and controls[22]==1,'square while fighting establishes guard without requiring held L2')
check(controls[140]==0 and controls[141]==0 and controls[142]==0 and controls[21]==0,'guard does not also punch or sprint')
fighting=false;now=stamp+200;packet({buttons=0x4000});tick(now)
check(controls[143]==1 and controls[25]==1,'guard survives a transient false combat-state flag')
for i=1,7 do now=stamp+200+i*200;packet({buttons=0x4000});tick(now) end
check(controls[143]==1 and controls[25]==1,'holding square keeps the guard stance after the initial combat grace interval')
now=now+10;packet();tick(now)
check(controls[143]==0 and controls[25]==0,'releasing square releases automatic targeting and block')
-- Expire the stance and rearm after idle; square is still jump outside combat.
arm(now+1400);now=now+10;packet({buttons=0x4000});tick(now)
check(controls[143]==0 and controls[25]==0 and controls[22]==1,'square remains jump outside combat rather than forcing permanent guard')
now=now+10;packet();tick(now);meleeTarget=77
now=now+10;packet({buttons=0x4000});tick(now)
check(controls[143]==1 and controls[25]==1,'known melee target enables guard before the combat flag appears')
meleeTarget=0;now=now+10;packet({lt=1,buttons=0x4100});tick(now)
check(controls[143]==0 and controls[25]==0 and controls[22]==0,'weapon wheel suppresses both guard and shared Space action')
now=now+10;events['coop_input:updateState']({ry=1});tick(now)
check(next(controls)==nil,'malformed packet stops aim, guard and movement together')
arm(now+10)
local n=#localEvents
now=now+10;packet({buttons=0x0002});tick(now)
check(#localEvents==n+1 and localEvents[#localEvents]=='brothers_world:interact' and controls[20]==1,
    'D-pad down emits one local interaction and preserves HUD info control')
now=now+10;packet({buttons=0x0002});tick(now)
check(#localEvents==n+1,'held D-pad down does not repeat world interaction')
now=now+10;packet();tick(now)
now=now+10;packet({buttons=0x0102});tick(now)
check(#localEvents==n+1,'weapon wheel suppresses optional interaction')
now=now+10;packet();tick(now)
events['coop_input:setRole'](1,2);tick(now+10)
check(next(controls)==nil,'role loss stops injected controls')
now=now+10;packet({buttons=0x0002});tick(now)
check(#localEvents==n+1,'inactive client cannot emit gamepad world interaction')
print(('Completed %d client checks; FiveM/Windows integration NOT tested'):format(passed))

end
local ok, err = pcall(run)
if not ok then io.stderr:write(tostring(err), "\n"); os.exit(1) end
