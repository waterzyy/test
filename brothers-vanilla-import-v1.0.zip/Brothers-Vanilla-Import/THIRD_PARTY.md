# Источники и лицензии

Сборка бесплатная. Она не содержит GTA V, FiveM-клиент, личные учётные данные или регистрационный ключ Cfx.re.

## Cfx.re FXServer

- Официальный каталог: https://runtime.fivem.net/artifacts/fivem/build_server_windows/master/
- Официальный resolver recommended: https://changelogs-live.fivem.net/api/changelog/versions/win32/server
- Схема resolver подтверждена исходниками txAdmin: https://github.com/tabarra/txAdmin/blob/master/core/modules/UpdateChecker/queryChangelogApi.ts
- FXServer binary отсутствует в ZIP и скачивается официально при первом Windows-запуске. Условия и авторизация Cfx.re сохраняются. Локальный SHA256 создаётся после HTTPS-загрузки; это не независимо опубликованная upstream checksum.

## Cfx.re stock resources

spawnmanager и baseevents скопированы без изменения из citizenfx/cfx-server-data, commit c6afa3909c763e3327ed76825e78453286c99f05.

- https://github.com/citizenfx/cfx-server-data
- https://codeload.github.com/citizenfx/cfx-server-data/zip/c6afa3909c763e3327ed76825e78453286c99f05
- SHA256 исходного ZIP: c74f781c9f81ee19e20e4df68846eb11d2b4117dafce83dce97464118bf932d1
- Оригинальные авторские заголовки сохранены. Примеры карт/gamemode/runcode и лишние тестовые ресурсы не включались. chat/sessionmanager/hardcap предоставляет текущий artifact, а не этот source snapshot.

## vMenu

Tom Grobbe / vMenu v3.7.0.

- https://github.com/TomGrobbe/vMenu
- https://github.com/TomGrobbe/vMenu/releases/download/v3.7.0/vMenu-v3.7.0.zip
- SHA256 официального HTTPS ZIP, вычисленная локально: 64f7b70c14fc53bd432f4839cf1bf516f71cf5130c583e42c5a9d62dd0775010
- Исходники: https://github.com/TomGrobbe/vMenu/tree/v3.7.0
- LICENSE.md сохранён внутри обоих ресурсов vMenu. Использование/изменение разрешено с сохранением авторства и ссылки; продажа запрещена. Пример permissions.cfg заменён памяткой, ACE явно ограничены хостом в server.cfg. Остальные файлы релиза сохранены.

## 7-Zip

Igor Pavlov, 7-Zip standalone 7zr 26.04.

- https://github.com/ip7z/7zip/releases/download/26.04/7zr.exe
- SHA256 опубликованного upstream digest: 256feca8e274e5da655e2a284fabafd9f554365eb164862089dacd4e8276d282
- Соответствующий исходник: tools/7zip/7z2604-src.tar.xz; SHA256 9691944c0fe0d01bb49373a704fb983fd33bc98b1738695179dfbf99ac1734f6
- LGPL2.1+, дополнительные исходные уведомления и RAR restriction сохранены в tools/7zip. Установка в систему не требуется. Нужен только для распаковки .7z официального FXServer.

## Контроллер

Исходный CoopInputRouter и coop_input предоставлены пользователем. Исправленные исходники включены. Зависимость сборки SharpDX.DirectInput 4.2.0 (SharpDX, MIT), Microsoft .NET 8 self-contained runtime: https://github.com/sharpdx/SharpDX и https://github.com/dotnet/runtime . Никакие x360ce/DS4Windows/виртуальные драйверы не включены и не устанавливаются этим комплектом.

## Новые игровые ресурсы и инструменты

brothers_world, brothers_admin, brothers_playground и PowerShell tooling написаны для этой бесплатной локальной сборки; новые части распространяются по LICENSE-NEW-RESOURCES.txt. Они используют только штатные GTA-ассеты и FiveM API. Это не полная замена сюжетной GTA и не античит для публичного сервера.
