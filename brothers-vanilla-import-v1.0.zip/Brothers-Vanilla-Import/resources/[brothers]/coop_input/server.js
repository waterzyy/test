/**
 * coop_input / server.js
 * ------------------------------------------------------------------
 * Receives the gamepad packets produced by CoopInputRouter.exe on
 * 127.0.0.1 UDP and relays them to exactly one client: "Player 2",
 * the FiveM window that runs in the background and therefore cannot
 * read the pad itself (RAGE mutes XInput without window focus).
 *
 * server.cfg:
 *     set coop_input_port 30126
 *     ensure coop_input
 *
 * Console commands:
 *     setp2 <id>     force a specific server id to be Player 2
 *     setp2 auto     go back to automatic selection
 *     coopstatus     show port / role / packet counters
 *
 * NOTE on the port: 30125 is usually FXServer's game endpoint. This
 * resource binds its own UDP receive socket on 30126 by default, and the
 * router sends packets to that socket from an ephemeral source port. The
 * resource having 30126 bound is expected; keep it separate from the
 * FXServer game endpoint.
 */

'use strict';

const dgram = require('dgram');

const CONVAR_PORT = 'coop_input_port';
const DEFAULT_PORT = 30126;
const HOST = '127.0.0.1';

const EV_REGISTER = 'coop_input:registerClient';
const EV_ROLE = 'coop_input:setRole';
const EV_STATE = 'coop_input:updateState';

/** @type {number|'auto'} */
let manualP2 = 'auto';
let p2Disabled = false;   // `setp2 0` -> nobody receives the pad
let p2ServerId = null;

let socket = null;
let boundPort = 0;
let rxPackets = 0;
let rxBadPackets = 0;
let lastPacketAt = 0;
let lastState = null;
let lastForwardedAt = 0;

// ------------------------------------------------------------------
//  helpers
// ------------------------------------------------------------------

function log(...args) {
    console.log('^5[coop_input]^7', ...args, '^7');
}

function warn(...args) {
    console.log('^1[coop_input]^7', ...args, '^7');
}

function configuredPort() {
    const raw = GetConvar(CONVAR_PORT, String(DEFAULT_PORT)).trim();
    const n = /^\d+$/.test(raw) ? Number(raw) : NaN;
    if (!Number.isInteger(n) || n < 1 || n > 65535) {
        warn(`convar ${CONVAR_PORT}="${raw}" is not a valid port, using ${DEFAULT_PORT}`);
        return DEFAULT_PORT;
    }
    return n;
}

/** Current player ids as numbers, ascending. */
function playerIds() {
    return Array.from({length: GetNumPlayerIndices()}, (_, i) => GetPlayerFromIndex(i))
        .map((id) => parseInt(id, 10))
        .filter((id) => Number.isFinite(id))
        .sort((a, b) => a - b);
}

function isOnline(id) {
    if (id === null || id === undefined) return false;
    const name = GetPlayerName(String(id));
    return typeof name === 'string' && name.length > 0;
}

// ------------------------------------------------------------------
//  role assignment
// ------------------------------------------------------------------

/**
 * Player 2 is resolved in this order:
 *   1. `setp2 <id>`           - explicit, survives reconnects
 *   2. client convar coop_slot=2 (launch the pad window with +coop_slot 2)
 *   3. the second id currently connected
 *
 * Option 2 is the only one that is deterministic for split-screen, because
 * both windows join from the same machine and the join order is a coin flip.
 */
function resolveP2(registeredSlots) {
    if (p2Disabled) return null;

    if (manualP2 !== 'auto') {
        return isOnline(manualP2) ? manualP2 : null;
    }

    for (const [id, slot] of Object.entries(registeredSlots)) {
        if (Number(slot) === 2) {
            const nid = parseInt(id, 10);
            if (isOnline(nid)) return nid;
        }
    }

    const ids = playerIds();
    return ids.length >= 2 ? ids[1] : null;
}

const registeredSlots = {};

function broadcastRoles(reason) {
    const next = resolveP2(registeredSlots);
    const changed = next !== p2ServerId;
    p2ServerId = next;

    for (const id of playerIds()) {
        const role = id === p2ServerId ? 2 : 1;
        emitNet(EV_ROLE, String(id), role, p2ServerId);
    }

    if (changed) {
        log(`player 2 = ${p2ServerId === null ? '(nobody yet, waiting for a second client)' : p2ServerId}` +
            ` [${reason}]`);
    }
    return changed;
}

// ------------------------------------------------------------------
//  net events
// ------------------------------------------------------------------

onNet(EV_REGISTER, function (slot) {
    const src = source;
    registeredSlots[String(src)] = (slot === undefined || slot === null) ? 0 : Number(slot);
    broadcastRoles(`client ${src} registered with coop_slot=${registeredSlots[String(src)]}`);
});

on('playerDropped', function () {
    const src = source;
    delete registeredSlots[String(src)];
    broadcastRoles(`client ${src} dropped`);
});

// ------------------------------------------------------------------
//  UDP receiver
// ------------------------------------------------------------------

function parseState(buf) {
    let text;
    try {
        text = buf.toString('utf8');
    } catch (e) {
        return null;
    }
    if (!text || text.charCodeAt(0) !== 0x7b /* { */) return null;

    let obj;
    try {
        obj = JSON.parse(text);
    } catch (e) {
        return null;
    }
    if (!obj || typeof obj !== 'object') return null;

    // Accept only complete normalized snapshots. Never turn a bad axis into 0
    // or clamp an unsigned DirectInput value into a permanent full deflection.
    for (const key of ['lx', 'ly', 'rx', 'ry', 'lt', 'rt', 'buttons']) {
        if (typeof obj[key] !== 'number' || !Number.isFinite(obj[key])) return null;
    }
    for (const key of ['lx', 'ly', 'rx', 'ry']) {
        if (obj[key] < -1 || obj[key] > 1) return null;
    }
    if (obj.lt < 0 || obj.lt > 1 || obj.rt < 0 || obj.rt > 1) return null;
    if (!Number.isInteger(obj.buttons) || obj.buttons < 0 || obj.buttons > 65535) return null;
    return {lx: obj.lx, ly: obj.ly, rx: obj.rx, ry: obj.ry,
        lt: obj.lt, rt: obj.rt, buttons: obj.buttons};
}

function startSocket() {
    const port = configuredPort();

    try {
        socket = dgram.createSocket({ type: 'udp4', reuseAddr: false });
    } catch (e) {
        warn('cannot create the UDP socket:', e && e.message);
        return;
    }

    socket.on('error', (err) => {
        warn('UDP socket error:', err && err.message);
        if (port === 30125) {
            warn('30125 is the FXServer game port - FXServer binds it for UDP as well.');
            warn(`Set "set ${CONVAR_PORT} 30126" in server.cfg and start the router with --port 30126.`);
        }
        try { socket.close(); } catch (e) { /* ignore */ }
        socket = null;
    });

    socket.on('message', (msg, rinfo) => {
        rxPackets++;
        lastPacketAt = Date.now();

        // Loopback only - anything else is a misconfiguration, not traffic.
        if (rinfo && rinfo.address && rinfo.address !== '127.0.0.1' && rinfo.address !== '::1' && rinfo.address !== '::ffff:127.0.0.1') {
            rxBadPackets++;
            return;
        }

        const state = parseState(msg);
        if (!state) {
            rxBadPackets++;
            if (rxBadPackets <= 5) warn(`discarded a malformed packet (${msg.length} bytes)`);
            return;
        }
        lastState = state;

        if (p2ServerId === null || !isOnline(p2ServerId)) return;

        emitNet(EV_STATE, String(p2ServerId), state);
        lastForwardedAt = Date.now();
    });

    socket.on('listening', () => {
        boundPort = port;
        log(`listening on udp://${HOST}:${port} (set ${CONVAR_PORT} <n> in server.cfg to change)`);
        log('start CoopInputRouter.exe with --port ' + port);
    });

    socket.bind(port, HOST);
}

// ------------------------------------------------------------------
//  console commands
// ------------------------------------------------------------------

RegisterCommand('setp2', (src, args) => {
    if (src !== 0) {
        // console only
        return;
    }
    const raw = String(args[0] || '').trim().toLowerCase();

    if (raw === 'auto' || raw === '') {
        p2Disabled = false;
        manualP2 = 'auto';
        log('player 2 selection set back to automatic');
        broadcastRoles('setp2 auto');
        return;
    }

    const id = /^\d+$/.test(raw) ? Number(raw) : NaN;
    if (!Number.isSafeInteger(id) || id < 0) {
        warn('usage: setp2 <server id> | setp2 auto');
        return;
    }
    if (id !== 0 && !isOnline(id)) {
        warn(`server id ${id} is not connected right now`);
        return;
    }
    p2Disabled = id === 0;
    manualP2 = id === 0 ? null : id; // 0 == "nobody is player 2"
    if (manualP2 === null) {
        log('player 2 disabled (setp2 0)');
    } else {
        log(`player 2 pinned to server id ${manualP2}`);
    }
    broadcastRoles(`setp2 ${raw}`);
}, true);

RegisterCommand('coopstatus', () => {
    const idle = lastPacketAt ? ((Date.now() - lastPacketAt) / 1000).toFixed(1) : 'never';
    log(`port      : ${socket && boundPort ? boundPort : '(not bound)'}`);
    log(`player 2  : ${p2ServerId} (mode: ${manualP2 === 'auto' ? 'auto' : 'pinned'})`);
    log(`players   : ${playerIds().join(', ') || '(none)'}`);
    log(`packets   : ${rxPackets} received, ${rxBadPackets} discarded`);
    log(`last rx   : ${idle}s ago`);
    log(`last state: ${lastState ? JSON.stringify(lastState) : '(none)'}`);
}, true);

// ------------------------------------------------------------------
//  boot / shutdown
// ------------------------------------------------------------------

setImmediate(() => {
    log('coop_input server starting');
    startSocket();
    broadcastRoles('resource start');

    // The second window can join much later than the first one.
    setInterval(() => broadcastRoles('poll'), 2000);
});

on('onResourceStop', (resource) => {
    if (resource !== GetCurrentResourceName()) return;
    if (p2ServerId !== null && isOnline(p2ServerId)) {
        emitNet(EV_ROLE, String(p2ServerId), 0, null);
    }
    if (socket) {
        try { socket.close(); } catch (e) { /* ignore */ }
        socket = null;
    }
});
