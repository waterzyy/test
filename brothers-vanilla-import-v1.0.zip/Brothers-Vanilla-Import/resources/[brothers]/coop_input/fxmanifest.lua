fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'coop_input'
author 'local split-screen kit'
description 'Replays a second XInput gamepad into a backgrounded FiveM client over loopback UDP'
version '1.4.0'

client_script 'client.lua'
server_script 'server.js'
