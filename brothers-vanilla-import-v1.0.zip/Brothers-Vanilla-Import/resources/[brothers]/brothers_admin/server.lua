-- Reserved group: group.brothers_host. Do not assign this group through identifiers.
-- Both local clients may share a license identifier; use the actual session source.
local GROUP = 'group.brothers_host'
local currentHost, manualHost = nil, nil
local stopped = false

local function playerId(value)
    local str = tostring(value or '')
    if not str:match('^%d+$') then return nil end
    local id = tonumber(str)
    if not id or id < 1 or id >= 65535 or id % 1 ~= 0 then return nil end
    return id
end

local function players(exclude, joining)
    local result = {}
    for _, value in ipairs(GetPlayers()) do
        local id = playerId(value)
        if id and id ~= exclude then result[id] = true end
    end
    -- playerJoining is authoritative and has the real source (unlike playerConnecting).
    -- Include it now even if the player list has not caught up on this server tick.
    if joining and joining ~= exclude then result[joining] = true end
    return result
end

local function membership(id, action)
    -- id never comes from an unchecked string. Commands cannot contain injected tokens.
    ExecuteCommand(('%s_principal player.%d %s'):format(action, id, GROUP))
end

local function refreshClient(id)
    if id then TriggerClientEvent('brothers_admin:refreshPermissions', id) end
end

local function assign(nextHost)
    if nextHost == currentHost then return end
    local previous = currentHost
    if previous then membership(previous, 'remove') end
    currentHost = nextHost
    if currentHost then membership(currentHost, 'add') end
    -- vMenu caches a client's own permissions. Refresh both promotion and demotion.
    refreshClient(previous)
    refreshClient(currentHost)
    print(('[brothers_admin] host=%s mode=%s'):format(
        currentHost and tostring(currentHost) or 'none', manualHost and 'manual' or 'auto'))
end

local function refresh(exclude, joining)
    if stopped then return end
    local online = players(exclude, joining)
    if manualHost and not online[manualHost] then manualHost = nil end
    local nextHost = manualHost
    if not nextHost then
        for id in pairs(online) do
            if not nextHost or id < nextHost then nextHost = id end
        end
    end
    assign(nextHost)
end

local function status()
    print(('[brothers_admin] host=%s; mode=%s; console: brothers_host <server id>|auto'):format(
        currentHost and tostring(currentHost) or 'none', manualHost and 'manual' or 'auto'))
end

RegisterCommand('brothers_host', function(src, args)
    -- Source 0 is the actual server console. A client command can never grant privileges.
    if src ~= 0 then return end
    if #args == 0 then status(); return end
    if #args ~= 1 then status(); return end
    if tostring(args[1]):lower() == 'auto' then
        manualHost = nil
        refresh()
        status()
        return
    end
    local id = playerId(args[1])
    if not id or not players()[id] then
        print('[brothers_admin] Select an online integer server ID, or auto. No changes made.')
        return
    end
    manualHost = id
    refresh()
    status()
end, true)

AddEventHandler('playerJoining', function()
    local id = playerId(source)
    if not id then return end
    -- A new session can reuse an offline numeric source left by a crashed resource.
    -- Clear the reserved principal before selecting its current role.
    membership(id, 'remove')
    refreshClient(id)
    if currentHost == id then currentHost = nil end
    if manualHost == id then manualHost = nil end
    refresh(nil, id)
end)

AddEventHandler('playerDropped', function()
    local id = playerId(source)
    if not id then return end
    if manualHost == id then manualHost = nil end
    -- FiveM may still list the dropping player while this event runs.
    refresh(id)
end)

AddEventHandler('onResourceStart', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    stopped = false
    manualHost = nil
    -- Resource restart must not leave cached session membership on the wrong player.
    -- This group is reserved for this resource; no other groups are touched.
    for id in pairs(players()) do
        membership(id, 'remove')
        refreshClient(id)
    end
    currentHost = nil
    refresh()
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    stopped = true
    if currentHost then membership(currentHost, 'remove'); refreshClient(currentHost) end
    currentHost, manualHost = nil, nil
end)

CreateThread(function()
    while true do
        Wait(2000)
        refresh()
    end
end)
