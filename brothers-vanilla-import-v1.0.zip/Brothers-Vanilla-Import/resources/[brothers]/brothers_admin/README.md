# brothers_admin

Session host assignment for a **loopback-only, two-player** server. The first real player source (lowest online server ID) receives `group.brothers_host`. Connect the keyboard/mouse client first. The second client does not inherit host privileges, even when both clients have the same Rockstar/license identifiers.

The resource never grants `group.admin`, never modifies identifiers, and has no client network event that grants privileges. It uses only `player.<server id>` session principals. Dropping the host revokes that principal before selecting the remaining player. A disconnected manually selected ID returns the mode to auto; a later player reusing that numeric ID does not inherit a stale manual selection.

Required server configuration, **before starting this resource**:

```cfg
add_ace resource.brothers_admin command.add_principal allow
add_ace resource.brothers_admin command.remove_principal allow

add_ace group.brothers_host vMenu.Everything allow
add_ace group.brothers_host vMenu.Staff allow
add_ace group.brothers_host brothers.playground allow
add_ace group.brothers_host brothers.manage allow

ensure brothers_admin
ensure vMenu
```

Do not add `group.brothers_host` to `builtin.everyone`, identifier principals, or unrelated resources. The group is reserved for this resource and should not be manually assigned elsewhere. Keep the whole server bound to `127.0.0.1`; automatic first-player administration is intended for the local brothers pack, not a public server.

Server console commands:

- `brothers_host`: show host ID and assignment mode.
- `brothers_host 2`: select an **online** server ID; example only, use the actual ID.
- `brothers_host auto`: restore the lowest online ID selection.

Only source 0 (server console) can run the command. Player commands and injected strings are ignored/rejected. No credentials are needed.

The host is assigned synchronously on `playerJoining`, which contains the real source; `playerConnecting` temporary IDs are not used. Role changes refresh vMenu's cached client permissions by asking the affected client to call vMenu's built-in `vMenu:RequestPermissions` event for itself. The client also asks when vMenu or this client resource starts. Every real join first clears any stale membership for that reused session source. A normal resource restart clears the dedicated group for current online session principals, then resolves the host again. Stopping this resource revokes the server ACE membership; if vMenu's already-open client UI still displays old buttons during a full stop, restart/reopen vMenu to refresh its display. Server ACE state is the authority.

There is a 2-second reconciliation loop; unchanged state produces no ACL writes. This resource does not scan the world, access the network, or write files.

Validation: mock FiveM Lua tests cover assignment, hot start/restart, manual transfer, demotion refresh, drop cleanup/ID reuse, temporary-ID avoidance, strict argument validation, console-only commands, stop cleanup, and the vMenu refresh bridge. These are API simulations; real FXServer/vMenu startup was not executed in the build environment.
