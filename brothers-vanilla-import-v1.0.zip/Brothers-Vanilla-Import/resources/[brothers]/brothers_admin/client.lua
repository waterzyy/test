-- vMenu owns and validates its permission response. We only request our own refresh.
local function refreshPermissions()
    if GetResourceState('vMenu') == 'started' then
        TriggerServerEvent('vMenu:RequestPermissions')
    end
end

RegisterNetEvent('brothers_admin:refreshPermissions', function()
    -- Only the server may trigger a refresh through this network event.
    if source ~= 65535 then return end
    refreshPermissions()
end)

AddEventHandler('onClientResourceStart', function(resource)
    if resource == GetCurrentResourceName() or resource == 'vMenu' then refreshPermissions() end
end)
