fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'brothers_admin'
author 'Brothers local co-op pack'
description 'Session-only host privileges for a loopback two-player server'
version '1.0.0'

server_script 'server.lua'
client_script 'client.lua'
