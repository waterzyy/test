FXServer is installed here from official Cfx.re recommended artifacts on the first Windows start. No server binary was downloaded or validated in this cloud environment.
