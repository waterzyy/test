#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${DOTNET:=dotnet}"
: "${LUA:=lua}"
: "${PWSH:=pwsh}"
: "${PYTHON:=python3}"
(cd 01-controller && DOTNET="$DOTNET" LUA="$LUA" bash run_tests.sh)
"$LUA" tests/world/test_core.lua
"$LUA" tests/world/test_server.lua
"$LUA" tests/world/test_client.lua
"$LUA" tests/admin/admin_harness.lua
"$LUA" tests/playground/run.lua
"$PWSH" -NoLogo -NoProfile -File tests/launcher/run.ps1
"$PYTHON" tests/verify_package.py
