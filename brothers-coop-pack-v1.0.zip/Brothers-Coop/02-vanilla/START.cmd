@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0..\tools\Start-Entry.ps1" -Profile vanilla
set "brothers_exit=%errorlevel%"
if not "%brothers_exit%"=="0" pause
exit /b %brothers_exit%
