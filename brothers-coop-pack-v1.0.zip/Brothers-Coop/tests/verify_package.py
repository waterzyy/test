from pathlib import Path
import hashlib,json,re,struct
ROOT=Path(__file__).resolve().parents[1]
count=0
def check(ok,name):
 global count
 assert ok,name
 count+=1
 print('PASS',name)
for folder,experimental in [('02-vanilla',False),('03-experimental',True)]:
 data=ROOT/folder/'server-data'
 cfg=(data/'server.cfg').read_text()
 check('endpoint_add_tcp "127.0.0.1:30125"' in cfg and 'endpoint_add_udp "127.0.0.1:30125"' in cfg,folder+' binds only loopback')
 check('sv_maxclients 2' in cfg and 'set onesync off' in cfg,folder+' is a two-client classic sync profile')
 check(not re.search(r'^\s*(?:set\s+)?sv_licenseKey\s',cfg,re.M),folder+' does not contain a license value')
 check('exec private/server-key.cfg' in cfg,folder+' imports only locally generated key')
 check('builtin.everyone' not in '\n'.join(x for x in cfg.splitlines() if not x.lstrip().startswith('#')),folder+' grants no everyone admin')
 check('exec resources' not in cfg and 'permissions.cfg' not in '\n'.join(x for x in cfg.splitlines() if not x.lstrip().startswith('#')),folder+' does not exec upstream permissive vMenu example')
 resource_dirs={p.parent.name:p.parent for p in (data/'resources').rglob('fxmanifest.lua')}
 required=re.findall(r'^ensure\s+(\S+)',cfg,re.M)
 bundled={'sessionmanager','hardcap','chat'}
 check(all(name in resource_dirs or name in bundled for name in required),folder+' every ensure has packaged or documented bundled resource')
 check(required.index('spawnmanager')<required.index('brothers_world') and required.index('brothers_admin')<required.index('vMenu'),folder+' spawn and admin start in the correct order')
 check(not {'basic-gamemode','fivem-map-skater','fivem-map-hipster','runcode'}.intersection(required),folder+' has no conflicting spawn map or dev runcode')
 check(('brothers_playground' in required)==experimental,folder+' selects the correct activity profile')
 check(('setr brothers_experimental '+('1' if experimental else '0')) in cfg,folder+' has matching world settings')
 for name in ('brothers_world','brothers_admin','coop_input'):
  canonical=(ROOT/'shared-resources'/name) if name!='coop_input' else (ROOT/'01-controller'/'coop_input')
  check(all((resource_dirs[name]/p.relative_to(canonical)).read_bytes()==p.read_bytes() for p in canonical.rglob('*') if p.is_file()),folder+' '+name+' matches canonical tested source')
 if experimental:
  canonical=ROOT/'experimental-resources'/'brothers_playground'
  check(all((resource_dirs['brothers_playground']/p.relative_to(canonical)).read_bytes()==p.read_bytes() for p in canonical.rglob('*') if p.is_file()),folder+' playground matches latest tested source')
 check((resource_dirs['vMenu']/'LICENSE.md').is_file(),folder+' retains vMenu license')
 for resource,path in resource_dirs.items():
  manifest=(path/'fxmanifest.lua').read_text(errors='replace')
  for filename in re.findall(r"['\"]([^'\"]+\.(?:lua|js|dll|html))['\"]",manifest):
   if filename.startswith('@'):continue
   assert (path/filename).is_file(),f'{resource}: missing {filename}'
 check(True,folder+' every manifest script/asset exists')
 check((ROOT/folder/'START.cmd').is_file(),folder+' includes a one-click entry point')
meta=json.loads((ROOT/'tools'/'upstream.json').read_text())
router=(ROOT/'01-controller'/'CoopInputRouter.exe').read_bytes()
check(hashlib.sha256(router).hexdigest()==meta['controller']['sha256'],'router matches shipped metadata digest')
o=struct.unpack_from('<I',router,0x3c)[0]
check(router[:2]==b'MZ' and router[o:o+4]==b'PE\0\0' and struct.unpack_from('<H',router,o+4)[0]==0x8664,'router is a Windows x64 executable')
seven=(ROOT/'tools'/'7zip'/'7zr.exe').read_bytes()
check(hashlib.sha256(seven).hexdigest()==meta['7zip']['sha256'],'7zr matches verified official upstream digest')
check((ROOT/'tools'/'7zip'/'7z2604-src.tar.xz').is_file(),'7zr redistribution contains corresponding source')
check(not list(ROOT.rglob('server-key.cfg')),'no private registration key is packaged')
check(not (ROOT/'runtime'/'server').exists(),'FXServer bootstrap status is honest: runtime not fabricated')
check(not any(p.suffix.lower() in {'.asi','.rpf','.ytd','.ymap'} for p in ROOT.rglob('*') if p.is_file()),'no external game hooks or streamed HD/map assets')
print(f'Completed {count} package/config checks. Actual FXServer runtime NOT launched.')
