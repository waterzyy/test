local function run()
local root=arg[1] or 'experimental-resources/brothers_playground'
local count=0
local function check(value,label) assert(value,label);count=count+1;print('PASS '..label) end
local function loadConfig(env)
    assert(loadfile(root..'/config.lua','t',env))()
    assert(loadfile(root..'/math.lua','t',env))()
end
local now,ids,events,commands,handlers,sent,threads=1000,{'1','2'},{},{},{},{},{}
local env=setmetatable({},{__index=_G})
loadConfig(env)
local function copy(v)
    if type(v)~='table' then return v end
    local o={};for k,item in pairs(v) do o[k]=copy(item) end;return o
end
env.GetPlayers=function()return ids end
env.GetGameTimer=function()return now end
env.IsPlayerAceAllowed=function(id,ace)return id==1 and ace=='brothers.playground' end
env.TriggerClientEvent=function(name,target,payload)sent[#sent+1]={name=name,target=target,payload=copy(payload)} end
env.RegisterNetEvent=function(name,fn)events[name]=fn end
env.RegisterCommand=function(name,fn)commands[name]=fn end
env.AddEventHandler=function(name,fn)handlers[name]=fn end
env.CreateThread=function(fn)threads[#threads+1]=coroutine.create(fn)end
env.Wait=function()coroutine.yield()end
env.GetCurrentResourceName=function()return 'brothers_playground'end
assert(loadfile(root..'/server.lua','t',env))()
local function event(name,src,...)
    env.source=src;events['brothers_playground:'..name](...)
end
local function state()
    for i=#sent,1,-1 do if sent[i].name=='brothers_playground:state' then return sent[i].payload end end
end
commands.coop_race(2,{})
check(state()==nil,'non-owner cannot start a round')
commands.coop_race(1,{})
check(state().kind=='race' and #state().members==2,'owner starts one race for both players')
local id=state().id
local function progress(who)
    for _,p in ipairs(state().members) do if p.id==who then return p.progress end end
end
event('mark',3,id,1);check(progress(1)==0,'non-member cannot report progress')
event('mark',1,id-1,1);check(progress(1)==0,'old round identifier rejected')
event('mark',1,id,2);check(progress(1)==0,'out-of-order checkpoint rejected')
event('mark',1,id,1);check(progress(1)==1,'ordered checkpoint accepted')
event('mark',1,id,2);check(progress(1)==1,'rapid checkpoint spam rejected')
now=now+300;event('mark',1,id,2);check(progress(1)==2,'next ordered checkpoint after cooldown accepted')
for i=3,#env.PlaygroundConfig.race do now=now+300;event('mark',1,id,i)end
check(state() and state().members[1].finished,'one finished player does not stop partner race')
for i=1,#env.PlaygroundConfig.race do now=now+300;event('mark',2,id,i)end
check(state()==nil,'race ends when both players finish')
commands.coop_challenge(1,{'hunt'});id=state().id
now=now+300;event('mark',1,id,1)
check(state().claimed[1]==1,'parcel claim belongs to first player')
now=now+300;event('mark',2,id,1)
check(state().claimed[1]==1 and state().members[2].score==0,'shared parcel cannot be claimed twice')
now=now+300;event('mark',1,id,1000)
check(state().members[1].score==1,'arbitrary client target index rejected')
for i=2,#env.PlaygroundConfig.hunt do now=now+300;event('mark',i%2+1,id,i)end
check(state()==nil,'team parcel hunt ends after all shared objectives')
commands.coop_challenge(1,{'targets'});id=state().id
check(state().kind=='targets','shooting activity starts without spawning a vehicle or NPC')
for i=1,#env.PlaygroundConfig.targets do now=now+300;event('mark',i%2+1,id,i)end
check(state()==nil,'target activity completes after finite shared target list')
commands.coop_race(1,{})
commands.coop_stop(2,{})
check(state()~=nil,'non-owner cannot stop partner activity')
commands.coop_stop(1,{})
check(state()==nil,'owner can cleanly stop activity')
commands.coop_race(1,{})
env.source=2;ids={'1'};handlers.playerDropped()
check(#state().members==1,'disconnect removes only dropped participant')
env.source=1;ids={};handlers.playerDropped()
check(state()==nil,'last disconnect clears active round')
ids={'1','2','3'};commands.coop_race(1,{})
check(state()==nil,'third player cannot silently enter a two-player activity')
ids={'1','2'};commands.coop_race(1,{})
local timer=threads[1];assert(coroutine.resume(timer))
now=now+env.PlaygroundConfig.durations.race+1;assert(coroutine.resume(timer))
check(state()==nil,'time limit cleans up abandoned activity')
commands.coop_challenge(1,{})
check(sent[#sent].name=='brothers_playground:menuAllowed','challenge without arguments opens owner selection menu')
event('menu',2);check(sent[#sent].name=='brothers_playground:notice','non-owner menu request is denied')
now=now+1000;event('menu',1);check(sent[#sent].name=='brothers_playground:menuAllowed','F7 menu granted to owner')
commands.coop_race(1,{});handlers.onResourceStop('brothers_playground')
check(sent[#sent].name=='brothers_playground:state' and sent[#sent].payload==nil,'resource stop clears clients')

local m=env.PlaygroundMath
check(m.distance2({x=0,y=0,z=0},{x=3,y=4,z=0})==25,'distance helper preserves expected squared distance')
check(m.segmentDistance2({x=5,y=1,z=0},{x=0,y=0,z=0},{x=10,y=0,z=0})==1,'bullet segment near target detected')
check(m.segmentDistance2({x=12,y=0,z=0},{x=0,y=0,z=0},{x=10,y=0,z=0})==4,'target beyond bullet impact is not hit')
check(m.segmentDistance2({x=-2,y=0,z=0},{x=0,y=0,z=0},{x=10,y=0,z=0})==4,'target behind shooter is not hit')
check(m.segmentDistance2({x=1,y=0,z=0},{x=0,y=0,z=0},{x=0,y=0,z=0})==1,'zero-length shot segment is safe')
local endpoint=m.aimEnd({x=0,y=0,z=0},{x=0,z=90},10)
check(math.abs(endpoint.x+10)<0.0001 and math.abs(endpoint.y)<0.0001,'game camera yaw converts into the expected ray')
local cli=setmetatable({},{__index=_G})
loadConfig(cli)
local ce,cc,ch={}, {}, {}
local clientRequests,notifications={},0
cli.source=65535
local openBlips,removed,nextBlip=0,0,1
cli.RegisterNetEvent=function(name,fn)ce[name]=fn end
cli.AddEventHandler=function(name,fn)ch[name]=fn end
cli.RegisterCommand=function(name,fn)cc[name]=fn end
cli.RegisterKeyMapping=function()end
cli.CreateThread=function()end
cli.GetGameTimer=function()return now end
cli.TriggerServerEvent=function(...)clientRequests[#clientRequests+1]={...}end
cli.PlayerPedId=function()return 42 end
cli.GetEntityCoords=function()return cli.PlaygroundConfig.hunt[1]end
cli.BeginTextCommandThefeedPost=function()end
cli.EndTextCommandThefeedPostTicker=function()notifications=notifications+1 end
cli.GetCurrentResourceName=function()return 'brothers_playground'end
cli.PlayerId=function()return 0 end
cli.GetPlayerServerId=function()return 1 end
cli.AddBlipForCoord=function()local b=nextBlip;nextBlip=nextBlip+1;openBlips=openBlips+1;return b end
cli.DoesBlipExist=function()return true end
cli.RemoveBlip=function()removed=removed+1;openBlips=openBlips-1 end
for _,name in ipairs({'SetBlipSprite','SetBlipColour','SetBlipScale','SetBlipAsShortRange','BeginTextCommandSetBlipName','AddTextComponentSubstringPlayerName','EndTextCommandSetBlipName','SetBlipRoute','SetBlipRouteColour'})do cli[name]=function()end end
assert(loadfile(root..'/client.lua','t',cli))()
cli.source=0
ce['brothers_playground:state']({id=999,kind='hunt',remaining=1000,claimed={},members={{id=1,progress=0}}})
check(openBlips==0,'locally spoofed round state cannot create activity blips')
ce['brothers_playground:menuAllowed']()
cc.fun()
check(#clientRequests==1 and clientRequests[1][1]=='brothers_playground:menu','locally spoofed menu grant does not open the host menu')
ce['brothers_playground:notice']('spoofed')
check(notifications==0,'locally spoofed network notice is ignored')
cli.source=65535
ce['brothers_playground:menuAllowed']()
cc.fun()
check(#clientRequests==1,'server menu grant opens the menu and its close stays local')
ce['brothers_playground:notice']('server notice')
check(notifications==1,'server-originated notice remains functional')
ce['brothers_playground:state']({id=7,kind='hunt',remaining=1000,claimed={},members={{id=1,progress=0}}})
check(openBlips==#cli.PlaygroundConfig.hunt,'hunt creates only finite configured map blips')
ch['brothers_world:interact']()
local lastRequest=clientRequests[#clientRequests]
check(lastRequest[1]=='brothers_playground:mark' and lastRequest[2]==7 and lastRequest[3]==1,
    'shared keyboard/pad interaction event collects a nearby parcel')
cli.source=0;ce['brothers_playground:state'](nil)
check(openBlips==#cli.PlaygroundConfig.hunt,'spoofed local state cannot clear an active server round')
cli.source=65535
ce['brothers_playground:state'](nil)
check(openBlips==0,'round end removes every owned blip')
ce['brothers_playground:state']({id=8,kind='race',remaining=1000,claimed={},members={{id=1,progress=0}}})
check(openBlips==1,'race displays only the next checkpoint route')
ch.onResourceStop('brothers_playground')
check(openBlips==0,'client resource stop removes all owned map markers')
check(cc.fun and cc.brothers_funmenu,'chat and F7 menu entry points registered')
print(('Completed %d playground checks; FiveM runtime NOT executed'):format(count))
end
local ok,err=pcall(run)
if not ok then io.stderr:write(tostring(err),'\n');os.exit(1)end
