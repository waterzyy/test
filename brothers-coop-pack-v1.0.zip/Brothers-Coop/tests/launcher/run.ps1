$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot '../../tools/Common.psm1') -Force
$script:passed=0
function Check([bool]$Condition,[string]$Name){if(-not $Condition){throw ('FAIL '+$Name)};$script:passed++;Write-Output ('PASS '+$Name)}
function Reject([scriptblock]$Action,[string]$Name){$failed=$false;try{&$Action}catch{$failed=$true};Check $failed $Name}
$good=[pscustomobject]@{recommended=12345;recommended_download='https://runtime.fivem.net/artifacts/fivem/build_server_windows/master/12345-abcdef0123456789/server.7z'}
$p=Get-ArtifactPlan $good
Check ($p.build -eq 12345) 'official recommended Windows artifact accepted'
foreach($url in @('http://runtime.fivem.net/artifacts/fivem/build_server_windows/master/12345-abcdef/server.7z',
'https://runtime.fivem.net.evil.example/artifacts/fivem/build_server_windows/master/12345-abcdef/server.7z',
'https://evil.example/server.7z','https://user:pass@runtime.fivem.net/artifacts/fivem/build_server_windows/master/12345-abcdef/server.7z',
'https://runtime.fivem.net:8443/artifacts/fivem/build_server_windows/master/12345-abcdef/server.7z',
'https://runtime.fivem.net/artifacts/fivem/build_server_linux/master/12345-abcdef/server.tar.xz',
'https://runtime.fivem.net/artifacts/fivem/build_server_windows/master/12345-abcdef/server.7z?redirect=evil',
'https://runtime.fivem.net/artifacts/fivem/build_server_windows/master/999-abcdef/server.7z')){
    $sample=[pscustomobject]@{recommended=12345;recommended_download=$url}
    Reject {Get-ArtifactPlan $sample} 'untrusted/mismatched artifact URL rejected'
}
Reject {Get-ArtifactPlan ([pscustomobject]@{recommended='123x';recommended_download=$good.recommended_download})} 'malformed recommended number rejected'
Assert-ArchivePaths @('FXServer.exe','citizen/system_resources/chat/server.lua')
Check $true 'normal archive members accepted'
foreach($member in @('../escape','citizen/../../escape','C:\escape','/absolute','\\server\share','citizen/file:stream')){
    Reject {Assert-ArchivePaths @($member)} 'archive path escape rejected'
}
Reject {Assert-ArchiveListing @('Path = server.7z','Path = citizen/link','Symbolic Link = ../../outside')} 'archive symlink rejected'
Reject {Assert-ArchiveListing @('Path = server.7z','Path = citizen/link','Hard Link = outside')} 'archive hardlink rejected'
Assert-ArchiveListing @('Path = server.7z','Path = FXServer.exe','Path = citizen/test.lua')
Check $true 'ordinary archive listing accepted'
# Synthetic strings only; no real credential is used by these tests.
$key='cfxk_example_test_key_1234567890'
Check (Test-LicenseValue $key) 'modern key shape accepted'
Check (-not(Test-LicenseValue 'paste-your-key-here')) 'placeholder key rejected'
Check (-not(Test-LicenseValue ($key+'";quit'))) 'config injection rejected'
Check ((Get-LicenseFromConfig ('# comment'+"`n"+'sv_licenseKey "'+$key+'"')) -eq $key) 'existing key extracted without executing cfg'
Check ((Get-LicenseFromConfig ('# sv_licenseKey "'+$key+'"')) -eq $null) 'commented key is not imported'
Check ((Get-LicenseFromConfig ('set sv_licenseKey "'+$key+'"')) -eq $key) 'legacy set form imported'
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('brothers-test-'+[Guid]::NewGuid().ToString('N'))
try{
    Write-Utf8File (Join-Path $testRoot 'citizen/core.lua') 'print("test")'
    Write-Utf8File (Join-Path $testRoot 'FXServer.exe') 'synthetic fixture; never executable'
    $manifest=@(Get-RuntimeManifest $testRoot)
    Check ($manifest.Count -eq 2) 'runtime manifest captures all fixture files'
    Assert-RuntimeManifest $testRoot $manifest
    Check $true 'unchanged runtime validates'
    Write-Utf8File (Join-Path $testRoot 'citizen/core.lua') 'changed'
    Reject {Assert-RuntimeManifest $testRoot $manifest} 'modified non-EXE runtime file rejected'
    Reject {Assert-RuntimeManifest $testRoot @()} 'empty runtime manifest rejected'
}finally{if(Test-Path -LiteralPath $testRoot){Remove-Item -LiteralPath $testRoot -Recurse -Force}}
$info=[pscustomobject]@{resources=@('spawnmanager','sessionmanager','hardcap','chat','baseevents','coop_input','brothers_world','brothers_admin','vMenu')}
Assert-ServerInfo $info
Check $true 'readiness requires actual named resources'
Reject {Assert-ServerInfo ([pscustomobject]@{resources=@('spawnmanager')})} 'open HTTP port without gameplay is not ready'
# Exercise the port preflight with actual loopback listeners, not just mocks.
$tcp=New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback,0)
$tcp.Start();$tcpPort=$tcp.LocalEndpoint.Port
try{Check (-not(Test-LoopbackPort $tcpPort 'tcp')) 'busy loopback TCP port is detected'}finally{$tcp.Stop()}
Check (Test-LoopbackPort $tcpPort 'tcp') 'released TCP port can be reused'
$udp=New-Object Net.Sockets.UdpClient
$udp.ExclusiveAddressUse=$true
$udp.Client.Bind((New-Object Net.IPEndPoint([Net.IPAddress]::Loopback,0)))
$udpPort=$udp.Client.LocalEndPoint.Port
try{Check (-not(Test-LoopbackPort $udpPort 'udp')) 'busy loopback UDP port is detected'}finally{$udp.Dispose()}
Check (Test-LoopbackPort $udpPort 'udp') 'released UDP port can be reused'
# Parse every launcher under PowerShell's parser, without running Windows processes.
$tools=Join-Path $PSScriptRoot '../../tools'
foreach($file in Get-ChildItem -LiteralPath $tools -File | Where-Object {$_.Extension -in @('.ps1','.psm1')}){
    $tokens=$null;$errors=$null
    [void][Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
    Check ($errors.Count -eq 0) ('PowerShell syntax: '+$file.Name)
}
Write-Output ('Completed '+$script:passed+' launcher checks. Windows FXServer and live official download NOT tested.')
