local function run()
local passed = 0
local function check(value, label)
    assert(value, label)
    passed = passed + 1
    print('PASS ' .. label)
end
local base = 'shared-resources/brothers_admin/'
local grants, writes, refreshes = {}, {}, {}
local online = {}
local function count(t) local n=0;for _ in pairs(t) do n=n+1 end;return n end
local function server()
    local handlers, commands, threads = {}, {}, {}
    local env = setmetatable({}, {__index = _G})
    env.source = nil
    env.GetPlayers = function()
        local copy = {};for _,id in ipairs(online) do copy[#copy+1] = tostring(id) end
        return copy
    end
    env.GetCurrentResourceName = function() return 'brothers_admin' end
    env.ExecuteCommand = function(command)
        local action, id = command:match('^(add)_principal player%.(%d+) group%.brothers_host$')
        if not action then action, id = command:match('^(remove)_principal player%.(%d+) group%.brothers_host$') end
        assert(action and id, 'unexpected command: ' .. command)
        id = tonumber(id);assert(id > 0 and id < 65535 and id % 1 == 0)
        writes[#writes+1] = {action=action,id=id}
        grants[id] = action == 'add' and true or nil
    end
    env.TriggerClientEvent = function(event, id)
        assert(event == 'brothers_admin:refreshPermissions' and type(id)=='number')
        refreshes[#refreshes+1] = id
    end
    env.print = function() end
    env.RegisterCommand = function(name, fn, restricted)
        assert(name=='brothers_host' and restricted==true)
        commands[name] = fn
    end
    env.AddEventHandler = function(name, fn) handlers[name]=fn end
    env.CreateThread = function(fn) threads[#threads+1]=coroutine.create(fn) end
    env.Wait = function(ms) assert(ms==2000);coroutine.yield() end
    assert(loadfile(base .. 'server.lua', 't', env))()
    local obj = {env=env, handlers=handlers}
    function obj.event(name, id, ...)
        local fn=handlers[name];assert(fn,'event not registered: '..name)
        env.source=id;fn(...);env.source=nil
    end
    function obj.command(src,args) commands.brothers_host(src,args) end
    function obj.poll()
        for _,co in ipairs(threads) do local ok,err=coroutine.resume(co);assert(ok,err) end
    end
    function obj.start() obj.event('onResourceStart',nil,'brothers_admin') end
    return obj
end

local s=server();s.start()
check(count(grants)==0,'empty server grants no administrator')
check(s.handlers.playerConnecting==nil,'temporary playerConnecting identifiers never grant privileges')
-- Joining callback includes real source immediately, before GetPlayers catches up.
s.event('playerJoining',2)
check(grants[2] and count(grants)==1,'real playerJoining source gets privileges before list catches up')
online={2};s.poll();s.poll()
local stable=#writes;s.poll()
check(#writes==stable,'unchanged polling does not rewrite ACL')
online={2,7};s.event('playerJoining',7)
check(grants[2] and not grants[7],'second client does not receive host group')
check(count(grants)==1,'only one session principal is a host')
local before=#writes;s.command(7,{'7'})
check(#writes==before and grants[2],'client cannot run console-only host command')
for _,args in ipairs({{'1; add_ace builtin.everyone command allow'},{'2 7'},{'0'},{'-2'},{'2.5'},
    {'2e0'},{'65535'},{'9999999999999999999999999'},{'3'},{' 2'},{'2','7'}}) do
    local n=#writes;s.command(0,args)
    check(#writes==n and grants[2], 'invalid/offline host arguments cannot change ACL: '..table.concat(args,'|'))
end
s.command(0,{})
check(grants[2] and #writes==before,'status command does not change privileges')
local oldRefresh=#refreshes
s.command(0,{'7'})
check(grants[7] and not grants[2],'console transfer revokes old host before promoting new host')
check(refreshes[oldRefresh+1]==2 and refreshes[oldRefresh+2]==7,'transfer refreshes both demoted and promoted vMenu clients')
s.poll()
check(grants[7] and not grants[2],'manual host is stable even when a lower ID remains online')
-- Drop can still be present in GetPlayers during the callback.
s.event('playerDropped',7)
check(grants[2] and not grants[7],'drop revokes manual host even while player list still includes dropped source')
online={2};s.poll()
online={2,7};grants[7]=true;s.event('playerJoining',7)
check(grants[2] and not grants[7],'reused old numeric ID does not inherit stale manual selection')
check(not grants[7],'new session removes reserved membership left by an interrupted old resource')
s.command(0,{'7'});s.command(0,{'auto'})
check(grants[2] and not grants[7],'auto restores lowest real online source')
-- Missing drop event is reconciled in the periodic sweep.
online={7};s.poll()
check(grants[7] and not grants[2],'poll removes vanished host membership and selects remaining player')
s.event('onResourceStop',nil,'another_resource')
check(grants[7],'unrelated resource stop does not change host')
s.event('onResourceStop',nil,'brothers_admin')
check(count(grants)==0,'resource stop revokes all membership created by this instance')
local n=#writes;s.poll()
check(#writes==n,'stopped reconciliation cannot regrant administrator')
-- A fresh resource instance cleans current online session principals before selecting.
grants[2]=true;grants[7]=true;online={7,2}
local newer=server();newer.start()
check(grants[2] and not grants[7] and count(grants)==1,'restart cleans stale current-session membership and restores one host')
newer.command(0,{'0007'})
check(grants[7] and not grants[2],'leading-zero integer input is normalized before command construction')
online={'not-a-player',0,'3.5',65535,2}
newer.command(0,{'auto'})
check(grants[2] and count(grants)==1,'malformed or reserved native player IDs are ignored')
local writesBefore=#writes;newer.event('playerJoining',65535)
check(#writes==writesBefore,'reserved network server source cannot become a player principal')
newer.event('onResourceStop',nil,'brothers_admin')
check(count(grants)==0,'final stop leaves no session host grant')

-- Client bridge can only request its own vMenu permissions, never grant anything.
local clientEvents, localEvents, requests = {}, {}, {}
local started=true
local env=setmetatable({}, {__index=_G})
env.GetCurrentResourceName=function() return 'brothers_admin' end
env.GetResourceState=function(resource) assert(resource=='vMenu');return started and 'started' or 'starting' end
env.TriggerServerEvent=function(name,...)
    assert(name=='vMenu:RequestPermissions' and select('#',...)==0)
    requests[#requests+1]=name
end
env.RegisterNetEvent=function(name,fn) clientEvents[name]=fn end
env.AddEventHandler=function(name,fn) localEvents[name]=fn end
assert(loadfile(base..'client.lua','t',env))()
for _,src in ipairs({0,1,2}) do env.source=src;clientEvents['brothers_admin:refreshPermissions']() end
check(#requests==0,'local/client-origin refresh events are ignored')
env.source=65535;clientEvents['brothers_admin:refreshPermissions']()
check(#requests==1,'server refresh requests only this client own vMenu permissions')
started=false;clientEvents['brothers_admin:refreshPermissions']()
check(#requests==1,'bridge waits when vMenu is not started')
started=true;localEvents.onClientResourceStart('vMenu')
check(#requests==2,'vMenu late start refreshes its client permissions')
localEvents.onClientResourceStart('brothers_admin')
check(#requests==3,'admin client late start refreshes its own permissions')
localEvents.onClientResourceStart('another_resource')
check(#requests==3,'unrelated client starts do not spam permission requests')
print(('Completed %d admin checks; FXServer/vMenu integration NOT tested'):format(passed))
end
local ok,err=pcall(run)
if not ok then io.stderr:write(tostring(err),'\n');os.exit(1) end
