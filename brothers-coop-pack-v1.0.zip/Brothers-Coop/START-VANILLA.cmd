@echo off
call "%~dp002-vanilla\START.cmd"
