PlaygroundConfig = {
    permission = 'brothers.playground',
    maxPlayers = 2,
    raceRadius = 18.0,
    huntRadius = 2.5,
    targetRadius = 0.9,
    shootingPad = {x=1732.0,y=3286.0,z=41.1},
    shootingPadRadius = 28.0,
    durations = {race=12*60*1000,hunt=10*60*1000,targets=8*60*1000},
    names = {race='City Sprint',hunt='Parcel Hunt',targets='Target Rush'},
    -- No teleports: follow the map route from the common city hub.
    race = {
        {x=214.0,y=-865.0,z=30.1},{x=156.0,y=-1020.0,z=29.3},
        {x=309.0,y=-1035.0,z=29.3},{x=417.0,y=-972.0,z=29.4},
        {x=486.0,y=-774.0,z=25.0},{x=274.0,y=-610.0,z=42.8},
        {x=125.0,y=-626.0,z=44.1},{x=-77.0,y=-756.0,z=43.7},
        {x=113.0,y=-865.0,z=31.1},{x=214.0,y=-865.0,z=30.1},
    },
    -- Outside the hub/shop area so one pad interaction cannot buy and collect together.
    hunt = {
        {x=177.2,y=-961.7,z=29.5},{x=206.9,y=-934.2,z=30.7},
        {x=239.7,y=-894.4,z=30.5},{x=290.5,y=-879.1,z=29.6},
        {x=316.8,y=-921.4,z=29.5},{x=282.5,y=-1003.8,z=29.3},
        {x=225.7,y=-1002.9,z=29.3},{x=163.7,y=-1017.2,z=29.3},
    },
    -- Virtual targets at Sandy Shores airstrip; no downloaded models or NPC spawners.
    targets = {
        {x=1744.0,y=3278.0,z=42.0},{x=1740.0,y=3274.0,z=42.5},
        {x=1736.0,y=3270.0,z=41.9},{x=1732.0,y=3266.0,z=42.7},
        {x=1749.0,y=3273.0,z=43.1},{x=1745.0,y=3269.0,z=42.2},
    },
}
