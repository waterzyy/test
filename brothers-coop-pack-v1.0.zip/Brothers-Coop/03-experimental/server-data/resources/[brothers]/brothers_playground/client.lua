local EV='brothers_playground:'
local activity, menuOpen, menuIndex, blips = nil, false, 1, {}
local endAt, lastAttempt, lastShot = 0, {}, 0
local menuItems={
    {key='race',label='1. City Sprint - checkpoint race'},
    {key='hunt',label='2. Parcel Hunt - collect together'},
    {key='targets',label='3. Target Rush - shooting range'},
    {key='stop',label='4. Stop the current activity'},
    {key='close',label='5. Close'},
}
local function clearBlips()
    for _,b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips={}
end
local function text(x,y,scale,value)
    SetTextFont(4);SetTextScale(0.0,scale);SetTextColour(255,255,255,240);SetTextOutline()
    BeginTextCommandDisplayText('STRING')
    for i=1,#value,90 do AddTextComponentSubstringPlayerName(value:sub(i,i+89)) end
    EndTextCommandDisplayText(x,y)
end
local function notice(value)
    print('[brothers_playground] '..tostring(value))
    BeginTextCommandThefeedPost('STRING')
    for i=1,#value,90 do AddTextComponentSubstringPlayerName(value:sub(i,i+89)) end
    EndTextCommandThefeedPostTicker(false,false)
end
local function me()
    if not activity then return nil end
    local id=GetPlayerServerId(PlayerId())
    for _,p in ipairs(activity.members) do if p.id==id then return p end end
end
local function addBlip(point,label,sprite,color,route)
    local b=AddBlipForCoord(point.x,point.y,point.z)
    SetBlipSprite(b,sprite);SetBlipColour(b,color);SetBlipScale(b,0.8)
    SetBlipAsShortRange(b,false)
    BeginTextCommandSetBlipName('STRING');AddTextComponentSubstringPlayerName(label);EndTextCommandSetBlipName(b)
    if route then SetBlipRoute(b,true);SetBlipRouteColour(b,color) end
    blips[#blips+1]=b
end
local function refreshBlips()
    clearBlips()
    if not activity then return end
    local p=me()
    if not p then activity=nil;return end
    if activity.kind=='race' then
        local point=PlaygroundConfig.race[p.progress+1]
        if point then addBlip(point,'City Sprint - next checkpoint',1,5,true) end
    elseif activity.kind=='hunt' then
        for index,point in ipairs(PlaygroundConfig.hunt) do
            if not activity.claimed[index] then addBlip(point,'Parcel '..index,478,3,false) end
        end
    else
        addBlip(PlaygroundConfig.shootingPad,'Target Rush - shooting pad',119,1,true)
    end
end
RegisterNetEvent(EV..'notice',function(value)
    if source~=65535 then return end
    notice(value)
end)
RegisterNetEvent(EV..'state',function(state)
    if source~=65535 then return end
    activity=state;lastAttempt={}
    if state then endAt=GetGameTimer()+state.remaining end
    refreshBlips()
end)
RegisterNetEvent(EV..'menuAllowed',function()
    if source~=65535 then return end
    menuOpen=true;menuIndex=1
end)
local function openMenu()
    if menuOpen then menuOpen=false;return end
    TriggerServerEvent(EV..'menu')
end
RegisterCommand('fun',openMenu,false)
RegisterCommand('brothers_funmenu',openMenu,false)
RegisterKeyMapping('brothers_funmenu','Brothers: cooperative activity menu','keyboard','F7')
local function attempt(index)
    if not activity or not me() then return end
    local now=GetGameTimer()
    if lastAttempt[index] and now-lastAttempt[index]<650 then return end
    lastAttempt[index]=now
    TriggerServerEvent(EV..'mark',activity.id,index)
end
local function collectNearby()
    if menuOpen or not activity or activity.kind~='hunt' then return end
    local pos=GetEntityCoords(PlayerPedId())
    for index,point in ipairs(PlaygroundConfig.hunt) do
        if not activity.claimed[index] and PlaygroundMath.distance2(pos,point)<=PlaygroundConfig.huntRadius^2 then
            attempt(index);return
        end
    end
end
-- Controller resource maps D-pad down to this local event; world shops act only at their own markers.
AddEventHandler('brothers_world:interact',collectNearby)
AddEventHandler('brothers_playground:interact',collectNearby)
local function marker(point,size,r,g,b,kind)
    DrawMarker(kind or 1,point.x,point.y,point.z-(kind and 0 or 1),0.0,0.0,0.0,0.0,0.0,0.0,
        size,size,kind and size or 0.9,r,g,b,165,false,false,2,false,nil,nil,false)
end
local function renderMenu()
    for _,control in ipairs({21,22,23,24,25,27,30,31,37,44,45,140,141,142,143}) do DisableControlAction(0,control,true) end
    DrawRect(0.50,0.33,0.56,0.34,8,15,25,225)
    text(0.235,0.175,0.48,'BROTHERS PLAYGROUND')
    for i,item in ipairs(menuItems) do
        text(0.235,0.22+(i-1)*0.042,0.34,(i==menuIndex and '~y~> ' or '~w~  ')..item.label)
    end
    text(0.235,0.447,0.28,'Arrow keys / Enter to select - Backspace or F7 to close')
    if IsControlJustPressed(0,172) then menuIndex=(menuIndex-2)%#menuItems+1 end
    if IsControlJustPressed(0,173) then menuIndex=menuIndex%#menuItems+1 end
    if IsControlJustPressed(0,177) then menuOpen=false end
    if IsControlJustPressed(0,191) then
        local key=menuItems[menuIndex].key;menuOpen=false
        if key~='close' then TriggerServerEvent(EV..'choose',key) end
    end
end
CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(100) end
    TriggerServerEvent(EV..'ready')
    while true do
        local sleep=500
        if menuOpen then sleep=0;renderMenu() end
        if activity then
            sleep=0
            local p=me()
            if not p then activity=nil;clearBlips()
            else
                local pos=GetEntityCoords(PlayerPedId())
                local left=math.max(0,math.ceil((endAt-GetGameTimer())/1000))
                local progress=activity.kind=='race' and p.progress or 0
                if activity.kind~='race' then for _ in pairs(activity.claimed) do progress=progress+1 end end
                text(0.015,0.78,0.36,('%s | %d/%d | %02d:%02d'):format(
                    PlaygroundConfig.names[activity.kind],progress,#PlaygroundConfig[activity.kind],math.floor(left/60),left%60))
                if activity.kind=='race' then
                    local index=p.progress+1;local point=PlaygroundConfig.race[index]
                    if point then
                        if PlaygroundMath.distance2D2(pos,point)<300^2 then marker(point,PlaygroundConfig.raceRadius*2,255,210,45) end
                        if not menuOpen and PlaygroundMath.distance2D2(pos,point)<=PlaygroundConfig.raceRadius^2 then attempt(index) end
                    else text(0.015,0.82,0.3,'Finished! Waiting for your partner.') end
                elseif activity.kind=='hunt' then
                    for index,point in ipairs(PlaygroundConfig.hunt) do
                        local d=PlaygroundMath.distance2(pos,point)
                        if not activity.claimed[index] and d<120^2 then
                            marker(point,1.2,50,190,255)
                            if d<=PlaygroundConfig.huntRadius^2 then text(0.30,0.88,0.34,'Collect parcel: E / Controller D-pad DOWN') end
                        end
                    end
                    -- Keyboard E and pad D-pad down both use brothers_world:interact.
                else
                    local pad=PlaygroundConfig.shootingPad
                    if PlaygroundMath.distance2(pos,pad)<200^2 then
                        marker(pad,3.0,60,220,100)
                        for index,point in ipairs(PlaygroundConfig.targets) do
                            if not activity.claimed[index] then marker(point,PlaygroundConfig.targetRadius*2,255,70,80,28) end
                        end
                    end
                    text(0.015,0.82,0.3,'Drive to Sandy Shores airstrip, stand on green pad and shoot red spheres.')
                    if not menuOpen and PlaygroundMath.distance2D2(pos,pad)<=PlaygroundConfig.shootingPadRadius^2 and
                        IsPedShooting(PlayerPedId()) and GetGameTimer()-lastShot>=180 then
                        lastShot=GetGameTimer()
                        local origin=GetGameplayCamCoord()
                        local endpoint=PlaygroundMath.aimEnd(origin,GetGameplayCamRot(2),160.0)
                        local hit,impact=GetPedLastWeaponImpactCoord(PlayerPedId())
                        if hit and impact and PlaygroundMath.distance2(origin,impact)>1 then endpoint=impact end
                        for index,point in ipairs(PlaygroundConfig.targets) do
                            if not activity.claimed[index] and PlaygroundMath.segmentDistance2(point,origin,endpoint)<=PlaygroundConfig.targetRadius^2 then
                                attempt(index);break
                            end
                        end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)
AddEventHandler('onResourceStop',function(name)
    if name~=GetCurrentResourceName() then return end
    menuOpen=false;activity=nil;clearBlips()
end)
