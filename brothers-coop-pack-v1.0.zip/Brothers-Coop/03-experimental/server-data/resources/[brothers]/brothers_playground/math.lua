PlaygroundMath = {}
function PlaygroundMath.distance2(a,b)
    local x,y,z=a.x-b.x,a.y-b.y,a.z-b.z
    return x*x+y*y+z*z
end
function PlaygroundMath.distance2D2(a,b)
    local x,y=a.x-b.x,a.y-b.y
    return x*x+y*y
end
-- Squared distance from a target to the finite bullet/aim segment, not an infinite line.
function PlaygroundMath.segmentDistance2(p,a,b)
    local x,y,z=b.x-a.x,b.y-a.y,b.z-a.z
    local length=x*x+y*y+z*z
    if length<0.000001 then return PlaygroundMath.distance2(p,a) end
    local t=((p.x-a.x)*x+(p.y-a.y)*y+(p.z-a.z)*z)/length
    t=math.max(0,math.min(1,t))
    return PlaygroundMath.distance2(p,{x=a.x+t*x,y=a.y+t*y,z=a.z+t*z})
end
function PlaygroundMath.aimEnd(origin,rotation,length)
    local pitch,yaw=math.rad(rotation.x),math.rad(rotation.z)
    local c=math.cos(pitch)
    return {x=origin.x-math.sin(yaw)*c*length,
        y=origin.y+math.cos(yaw)*c*length,z=origin.z+math.sin(pitch)*length}
end
