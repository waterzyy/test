local round, serial = nil, 0
local limits = {}
local EV = 'brothers_playground:'
local function notice(target,text)
    if target==0 then print('[brothers_playground] '..text)
    else TriggerClientEvent(EV..'notice',target,text) end
end
local function allowed(src)
    return src==0 or IsPlayerAceAllowed(src,PlaygroundConfig.permission)
end
local function throttle(src,key,gap)
    local bucket=limits[src] or {};limits[src]=bucket
    local now=GetGameTimer()
    if bucket[key] and now-bucket[key]<gap then return false end
    bucket[key]=now;return true
end
local function players()
    local result={}
    for _,id in ipairs(GetPlayers()) do
        local n=tonumber(id)
        if n then result[#result+1]=n end
    end
    table.sort(result)
    return result
end
local function snapshot()
    if not round then return nil end
    local remaining=math.max(0,PlaygroundConfig.durations[round.kind]-(GetGameTimer()-round.started))
    local members={}
    for id,p in pairs(round.members) do
        members[#members+1]={id=id,progress=p.progress,score=p.score,finished=p.finished}
    end
    table.sort(members,function(a,b)return a.id<b.id end)
    return {id=round.id,kind=round.kind,remaining=remaining,claimed=round.claimed,members=members}
end
local function broadcast()
    TriggerClientEvent(EV..'state',-1,snapshot())
end
local function finish(reason)
    if not round then return end
    local kind=PlaygroundConfig.names[round.kind]
    local scores={}
    for id,p in pairs(round.members) do
        scores[#scores+1]=('P%s: %s'):format(id,round.kind=='race' and
            (p.finished and ('%.1fs'):format(p.finished/1000) or 'not finished') or tostring(p.score))
    end
    table.sort(scores)
    round=nil
    TriggerClientEvent(EV..'state',-1,nil)
    notice(-1,kind..' — '..reason..' | '..table.concat(scores,' / '))
end
local function start(src,kind)
    if not allowed(src) then notice(src,'Only Player 1 / the local host may start activities.');return end
    if not PlaygroundConfig.names[kind] then return end
    local ids=players()
    if #ids<1 then if src~=0 then notice(src,'Connect a player first.') end;return end
    if #ids>PlaygroundConfig.maxPlayers then notice(src,'This activity supports at most two players.');return end
    if round then finish('replaced by the host') end
    serial=serial+1
    round={id=serial,kind=kind,started=GetGameTimer(),claimed={},members={}}
    for _,id in ipairs(ids) do round.members[id]={progress=0,score=0,lastMark=-100000,finished=false} end
    broadcast()
    notice(-1,PlaygroundConfig.names[kind]..' started. Follow the map markers; F7 / /fun opens the activity menu.')
end
RegisterNetEvent(EV..'ready',function()
    local src=tonumber(source)
    if not src or not throttle(src,'ready',2000) then return end
    TriggerClientEvent(EV..'state',src,snapshot())
end)
RegisterNetEvent(EV..'menu',function()
    local src=tonumber(source)
    if not src or not throttle(src,'menu',500) then return end
    if allowed(src) then TriggerClientEvent(EV..'menuAllowed',src)
    else notice(src,'Player 1 opens activities with F7. Join the active game using the map markers.') end
end)
RegisterNetEvent(EV..'choose',function(kind)
    local src=tonumber(source)
    if not src or not throttle(src,'choose',500) or not allowed(src) then return end
    if kind=='stop' then finish('stopped by the host') else start(src,kind) end
end)
RegisterNetEvent(EV..'mark',function(id,index)
    local src=tonumber(source)
    if not round or id~=round.id or not src then return end
    local p=round.members[src]
    if not p or p.finished or type(index)~='number' or index%1~=0 then return end
    local points=PlaygroundConfig[round.kind]
    if index<1 or index>#points then return end
    local now=GetGameTimer()
    if now-p.lastMark<250 then return end
    if round.kind=='race' then
        if index~=p.progress+1 then return end
        p.lastMark=now;p.progress=index
        if index==#points then
            p.finished=now-round.started
            notice(-1,('Player %s finished City Sprint in %.1fs.'):format(src,p.finished/1000))
        end
        local everyone=true
        for _,member in pairs(round.members) do if not member.finished then everyone=false;break end end
        if everyone then finish('everyone finished');return end
    else
        if round.claimed[index] then return end
        p.lastMark=now;p.score=p.score+1;round.claimed[index]=src
        local count=0
        for _ in pairs(round.claimed) do count=count+1 end
        if count==#points then finish('team completed all '..count..' objectives');return end
    end
    broadcast()
end)
RegisterCommand('coop_race',function(src)start(tonumber(src),'race')end,false)
RegisterCommand('coop_challenge',function(src,args)
    src=tonumber(src)
    if not allowed(src) then notice(src,'Only the host can start an activity.');return end
    local kind=args[1]
    if not kind or kind=='' then
        if src==0 then start(0,'hunt') else TriggerClientEvent(EV..'menuAllowed',src) end
    elseif kind=='hunt' or kind=='targets' then start(src,kind)
    else notice(src,'Use /coop_challenge hunt or /coop_challenge targets; /fun opens the menu.') end
end,false)
RegisterCommand('coop_stop',function(src)
    if allowed(tonumber(src)) then finish('stopped by the host') end
end,false)
RegisterCommand('coop_help',function(src)
    notice(tonumber(src),'F7 or /fun: activity menu. /coop_race | /coop_challenge [hunt|targets] | /coop_stop. Parcel: E / pad D-pad down. Targets: shoot the colored spheres.')
end,false)
AddEventHandler('playerDropped',function()
    local src=tonumber(source)
    limits[src]=nil
    if not round or not round.members[src] then return end
    round.members[src]=nil
    local count,allFinished=0,true
    for _,p in pairs(round.members) do count=count+1;if not p.finished then allFinished=false end end
    if count==0 then finish('players disconnected')
    elseif round.kind=='race' and allFinished then finish('remaining player finished')
    else broadcast();notice(-1,'Partner disconnected; the remaining player can finish or stop the activity.') end
end)
CreateThread(function()
    while true do
        Wait(1000)
        if round and GetGameTimer()-round.started>=PlaygroundConfig.durations[round.kind] then finish('time limit reached') end
    end
end)
AddEventHandler('onResourceStop',function(name)
    if name~=GetCurrentResourceName() then return end
    TriggerClientEvent(EV..'state',-1,nil)
end)
