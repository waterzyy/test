[CmdletBinding()]
param([string]$Root = (Split-Path -Parent $PSScriptRoot))
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
$private = Join-Path $Root 'private'
$keyFile = Join-Path $private 'server-key.cfg'
$key = $null
if (Test-Path -LiteralPath $keyFile) {
    $key = Get-LicenseFromConfig (Get-Content -Raw -LiteralPath $keyFile)
}
if (-not $key) {
    Write-Host 'First start: a FREE Cfx.re server registration key is required.'
    Write-Host 'Create it at https://portal.cfx.re/ . Never send the key in chat.'
    Write-Host 'You can reuse the key from your existing local FXServer config.'
    $oldPath = Read-Host 'Path to existing server.cfg, or press Enter to enter the key privately'
    if (-not [string]::IsNullOrWhiteSpace($oldPath)) {
        $oldPath = $oldPath.Trim().Trim('"')
        if (-not (Test-Path -LiteralPath $oldPath -PathType Leaf)) { throw 'The supplied config file does not exist.' }
        $key = Get-LicenseFromConfig (Get-Content -Raw -LiteralPath $oldPath)
        if (-not $key) { throw 'No valid sv_licenseKey found in that file. Try entering your key on the next start.' }
    } else {
        $secret = Read-Host 'Paste your Cfx.re server key (hidden)' -AsSecureString
        $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
        try { $key = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer).Trim() }
        finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer); $secret.Dispose() }
        if (-not (Test-LicenseValue $key)) { throw 'The key format is not recognised. Copy the complete registration key from Cfx Portal.' }
    }
    Write-Utf8File $keyFile ('sv_licenseKey "' + $key + '"' + [Environment]::NewLine)
    if ($env:OS -eq 'Windows_NT') {
        # Local user-only ACL. No credentials are passed to another process.
        $acl = New-Object Security.AccessControl.FileSecurity
        $acl.SetAccessRuleProtection($true,$false)
        $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User
        $rule = New-Object Security.AccessControl.FileSystemAccessRule($sid,'FullControl','Allow')
        $acl.AddAccessRule($rule)
        Set-Acl -LiteralPath $keyFile -AclObject $acl
    }
}
foreach ($profile in @('02-vanilla','03-experimental')) {
    $target = Join-Path $Root ($profile + '/server-data/private/server-key.cfg')
    Write-Utf8File $target ('sv_licenseKey "' + $key + '"' + [Environment]::NewLine)
    if ($env:OS -eq 'Windows_NT') { Set-Acl -LiteralPath $target -AclObject (Get-Acl -LiteralPath $keyFile) }
}
$key = $null
Write-Host 'Server key is stored locally in private folders. Do not share those folders.'
