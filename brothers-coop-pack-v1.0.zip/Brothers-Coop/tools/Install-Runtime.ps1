[CmdletBinding()]
param([string]$Root = (Split-Path -Parent $PSScriptRoot))
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
if ($env:OS -ne 'Windows_NT') { throw 'FXServer Windows installation must run on Windows 10/11 x64.' }
if (-not [Environment]::Is64BitOperatingSystem) { throw 'Windows x64 is required.' }
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$runtime = Join-Path $Root 'runtime'
$server = Join-Path $runtime 'server'
$statePath = Join-Path $runtime 'fxserver.lock.json'
$exe = Join-Path $server 'FXServer.exe'
if ((Test-Path -LiteralPath $exe) -and (Test-Path -LiteralPath $statePath)) {
    $state = Get-Content -Raw -LiteralPath $statePath | ConvertFrom-Json
    Assert-RuntimeManifest $server $state.files
    Write-Host ('FXServer build ' + $state.build + ' is already installed and pinned.')
    return
}
if (Test-Path -LiteralPath $server) { throw 'runtime/server exists without a valid installation lock. Preserve it and rename it before reinstalling.' }
Write-Host 'Downloading the current recommended Windows FXServer from official Cfx.re HTTPS sources.'
Write-Host 'This happens once. Your key is not sent to the installer or GitHub.'
$resolver = 'https://changelogs-live.fivem.net/api/changelog/versions/win32/server'
$metadata = Invoke-RestMethod -Uri $resolver -TimeoutSec 45
$plan = Get-ArtifactPlan $metadata
$cache = Join-Path $runtime 'cache'
[void][IO.Directory]::CreateDirectory($cache)
$archive = Join-Path $cache ('fxserver-' + $plan.build + '.7z')
$lockForCache = Join-Path $cache ('fxserver-' + $plan.build + '.json')
if ((Test-Path -LiteralPath $archive) -and (Test-Path -LiteralPath $lockForCache)) {
    $cached = Get-Content -Raw -LiteralPath $lockForCache | ConvertFrom-Json
    if ($cached.url -ne $plan.url) { throw 'Cached artifact URL does not match the official recommended build.' }
    Assert-FileHash $archive ([string]$cached.sha256)
} else {
    $partial = $archive + '.download'
    Invoke-WebRequest -UseBasicParsing -Uri $plan.url -OutFile $partial -TimeoutSec 600
    if ((Get-Item -LiteralPath $partial).Length -lt 1MB) { throw 'The official artifact download is unexpectedly small.' }
    Move-Item -LiteralPath $partial -Destination $archive -Force
    # First-use trust is official HTTPS. This local digest detects subsequent changes;
    # it is NOT represented as an independently published upstream checksum.
    $cached = [pscustomobject]@{build=$plan.build;url=$plan.url;sha256=(Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash}
    Write-Utf8File $lockForCache ($cached | ConvertTo-Json)
}
$seven = Join-Path $PSScriptRoot '7zip/7zr.exe'
Assert-FileHash $seven '256feca8e274e5da655e2a284fabafd9f554365eb164862089dacd4e8276d282'
$listing = @(& $seven l -slt -- $archive)
if ($LASTEXITCODE -ne 0) { throw '7-Zip could not inspect the artifact.' }
Assert-ArchiveListing $listing
$staging = Join-Path $runtime ('.install-' + [Guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($staging)
try {
    & $seven x -y ('-o' + $staging) -- $archive
    if ($LASTEXITCODE -ne 0) { throw 'Artifact extraction failed.' }
    $stagedExe = Join-Path $staging 'FXServer.exe'
    if (-not (Test-Path -LiteralPath $stagedExe) -or -not (Test-Path -LiteralPath (Join-Path $staging 'citizen'))) {
        throw 'The artifact is missing FXServer.exe or citizen.'
    }
    Move-Item -LiteralPath $staging -Destination $server
    $state = [pscustomobject]@{build=$plan.build;url=$plan.url;archive_sha256=$cached.sha256;files=@(Get-RuntimeManifest $server);installed_utc=[DateTime]::UtcNow.ToString('o');trust='Official HTTPS on first use; locally pinned thereafter'}
    Write-Utf8File $statePath ($state | ConvertTo-Json -Depth 5)
} finally {
    if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force }
}
Write-Host 'Official FXServer installed. Subsequent starts reuse this pinned build.'
