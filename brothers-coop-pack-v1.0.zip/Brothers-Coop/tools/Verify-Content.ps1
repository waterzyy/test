$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
$root=Split-Path -Parent $PSScriptRoot
$status=0
try{
    $manifest=Get-Content -Raw -LiteralPath (Join-Path $root 'FILES.sha256.json') | ConvertFrom-Json
    Assert-RuntimeManifest $root $manifest
    Write-Host ('Verified '+@($manifest).Count+' original package files. This is an integrity check, not an antivirus scan.') -ForegroundColor Green
}catch{$status=1;Write-Host $_.Exception.Message -ForegroundColor Red}
[void](Read-Host 'Press Enter to close')
exit $status
