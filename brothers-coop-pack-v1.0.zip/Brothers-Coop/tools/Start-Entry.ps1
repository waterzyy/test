param([ValidateSet('vanilla','experimental')][string]$Profile='vanilla')
$ErrorActionPreference='Stop'
$exitCode=0
try { & (Join-Path $PSScriptRoot 'Start-Server.ps1') -Profile $Profile }
catch { $exitCode=1;Write-Host '';Write-Host $_.Exception.Message -ForegroundColor Red;Write-Host 'See README_RU.md. Do not disable antivirus or TLS verification.' }
finally { [void](Read-Host 'Press Enter to close this window') }
exit $exitCode
