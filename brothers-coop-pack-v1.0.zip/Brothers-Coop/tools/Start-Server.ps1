[CmdletBinding()]
param([ValidateSet('vanilla','experimental')][string]$Profile='vanilla')
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'Common.psm1') -Force
if ($env:OS -ne 'Windows_NT') { throw 'Use START.cmd on your Windows gaming PC.' }
$root=Split-Path -Parent $PSScriptRoot
$folder=if($Profile -eq 'vanilla'){'02-vanilla'}else{'03-experimental'}
$data=Join-Path $root ($folder+'/server-data')
$server=$null;$router=$null;$held=$false
$mutex=New-Object Threading.Mutex($false,'Local\BrothersCoop-FXServer')
try {
    try { $held=$mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $held=$true }
    if(-not $held){throw 'Another Brothers server is already running. Close its launcher first.'}
    if(Get-Process -Name 'CoopInputRouter' -ErrorAction SilentlyContinue){throw 'Close the old CoopInputRouter before starting this pack.'}
    foreach($p in @(@(30125,'tcp'),@(30125,'udp'),@(30126,'udp'))){
        if(-not(Test-LoopbackPort $p[0] $p[1])){throw ('Local port '+$p[0]+'/'+$p[1]+' is occupied. Close your old local server; do not open ports in the router.')}
    }
    $bundled=Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'upstream.json') | ConvertFrom-Json
    Assert-FileHash (Join-Path $root '01-controller/CoopInputRouter.exe') ([string]$bundled.controller.sha256)
    & (Join-Path $PSScriptRoot 'Install-Runtime.ps1') -Root $root
    & (Join-Path $PSScriptRoot 'Configure-Key.ps1') -Root $root
    $server=Start-Process -FilePath (Join-Path $root 'runtime/server/FXServer.exe') -ArgumentList @('+exec','server.cfg') -WorkingDirectory $data -PassThru
    Write-Host 'Waiting for FXServer and the required resources (up to 90 seconds)...'
    $deadline=[DateTime]::UtcNow.AddSeconds(90);$ready=$false;$lastReason='not listening'
    while([DateTime]::UtcNow -lt $deadline){
        if($server.HasExited){throw ('FXServer exited with code '+$server.ExitCode+'. Read its console for the license or startup error.')}
        try{
            $info=Invoke-RestMethod -Uri 'http://127.0.0.1:30125/info.json' -TimeoutSec 2
            Assert-ServerInfo $info
            if($Profile -eq 'experimental' -and @($info.resources) -notcontains 'brothers_playground'){throw 'brothers_playground has not started.'}
            $ready=$true;break
        }catch{$lastReason=$_.Exception.Message}
        Start-Sleep -Milliseconds 500
    }
    if(-not $ready){throw ('Server readiness failed: '+$lastReason+'. Inspect the FXServer console. An invalid/expired key must be corrected locally.')}
    $router=Start-Process -FilePath (Join-Path $root '01-controller/CoopInputRouter.exe') -ArgumentList @('--directinput','--port','30126','--hz','60') -WorkingDirectory (Join-Path $root '01-controller') -PassThru
    Write-Host ''
    Write-Host 'READY. Keep this launcher and the server console open.' -ForegroundColor Green
    Write-Host '1. Connect the keyboard/mouse FiveM window FIRST.'
    Write-Host '2. Connect the gamepad window SECOND.'
    Write-Host 'In F8 in EACH existing FiveM window: connect 127.0.0.1:30125'
    Write-Host 'Release all pad controls briefly. M: host vMenu. F6: help. F7: experimental games.'
    Write-Host 'Close the server console or press Ctrl+C here to stop the server and the router started by this launcher.'
    $reportedRouter=$false
    while(-not $server.HasExited){
        if($router.HasExited -and -not $reportedRouter){Write-Warning 'The gamepad router has stopped. Keyboard play remains available; restart this launcher when convenient.';$reportedRouter=$true}
        Start-Sleep -Seconds 1
    }
}finally{
    # Stop only child processes created here. Never kill other FXServer/FiveM instances.
    if($router -and -not $router.HasExited){Stop-Process -Id $router.Id -ErrorAction SilentlyContinue}
    if($server -and -not $server.HasExited){Stop-Process -Id $server.Id -ErrorAction SilentlyContinue}
    if($held){$mutex.ReleaseMutex()}
    $mutex.Dispose()
}
