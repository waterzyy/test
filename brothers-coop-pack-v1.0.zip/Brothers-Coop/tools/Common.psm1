Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Write-Utf8File([string]$Path, [string]$Text) {
    $parent = Split-Path -Parent $Path
    if ($parent -and -not (Test-Path -LiteralPath $parent)) { [void][IO.Directory]::CreateDirectory($parent) }
    [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding($false)))
}
function Get-ArtifactPlan($Metadata) {
    if ($null -eq $Metadata) { throw 'The official build resolver returned no metadata.' }
    $version = 0
    if (-not [int]::TryParse([string]$Metadata.recommended, [ref]$version) -or $version -lt 1) {
        throw 'Invalid recommended FXServer build number.'
    }
    $address = [string]$Metadata.recommended_download
    $uri = $null
    if (-not [Uri]::TryCreate($address, [UriKind]::Absolute, [ref]$uri)) { throw 'Invalid artifact URL.' }
    if ($uri.Scheme -ne 'https' -or $uri.Host -ne 'runtime.fivem.net' -or $uri.Port -ne 443 -or
        $uri.UserInfo -or $uri.Query -or $uri.Fragment) { throw 'Artifact must use the official HTTPS host.' }
    if ($uri.AbsolutePath -notmatch '^/artifacts/fivem/build_server_windows/master/(?<build>[0-9]+)-[0-9a-fA-F]+/server\.7z$') {
        throw 'Unexpected Windows FXServer artifact path.'
    }
    if ([int]$Matches.build -ne $version) { throw 'Resolver build number does not match its artifact URL.' }
    return [pscustomobject]@{build=$version; url=$uri.AbsoluteUri}
}
function Assert-ArchivePaths([string[]]$Paths) {
    foreach ($entry in $Paths) {
        $entry = $entry.Replace('\','/')
        if ($entry.StartsWith('/') -or $entry -match '(^|/)\.\.(/|$)' -or $entry -match ':' -or $entry.Contains([char]0)) {
            throw 'Unsafe archive member path.'
        }
    }
}
function Assert-ArchiveListing([string[]]$Lines) {
    foreach ($line in $Lines) {
        if ($line -match '^(Symbolic Link|Hard Link|Link)\s*=\s*\S') { throw 'Archive links are not allowed.' }
    }
    $members = @($Lines | Where-Object { $_ -like 'Path = *' } | Select-Object -Skip 1 | ForEach-Object { $_.Substring(7) })
    if ($members.Count -eq 0) { throw 'Artifact contains no files.' }
    Assert-ArchivePaths $members
}
function Get-RuntimeManifest([string]$Directory) {
    $base = [IO.Path]::GetFullPath($Directory).TrimEnd([char[]]'\/') + [IO.Path]::DirectorySeparatorChar
    return @(Get-ChildItem -LiteralPath $Directory -Recurse -File | ForEach-Object {
        [pscustomobject]@{path=$_.FullName.Substring($base.Length).Replace('\','/');sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash}
    })
}
function Assert-RuntimeManifest([string]$Directory, $Manifest) {
    if (@($Manifest).Count -lt 1) { throw 'Runtime file manifest is empty.' }
    foreach ($entry in @($Manifest)) {
        Assert-ArchivePaths @([string]$entry.path)
        Assert-FileHash (Join-Path $Directory ([string]$entry.path)) ([string]$entry.sha256)
    }
}
function Assert-FileHash([string]$Path, [string]$Expected) {
    if ($Expected -notmatch '^[0-9a-fA-F]{64}$') { throw 'Invalid pinned SHA256.' }
    $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
    if ($actual -ne $Expected) { throw ('SHA256 mismatch: ' + (Split-Path -Leaf $Path)) }
}
function Test-LicenseValue([string]$Value) {
    return $Value -match '^(?:cfxk_[A-Za-z0-9_-]{12,240}|[A-Fa-f0-9]{32,64})$'
}
function Get-LicenseFromConfig([string]$Text) {
    $found = [regex]::Matches($Text, '(?im)^\s*(?:set\s+)?sv_licenseKey\s+(?:"(?<key>[^"]+)"|(?<key>[^\s#;]+))')
    for ($i=$found.Count-1; $i -ge 0; $i--) {
        $key = $found[$i].Groups['key'].Value.Trim()
        if (Test-LicenseValue $key) { return $key }
    }
    return $null
}
function Assert-ServerInfo($Info) {
    if ($null -eq $Info -or -not $Info.PSObject.Properties['resources']) { throw 'FXServer info.json is not ready.' }
    foreach ($resource in @('spawnmanager','sessionmanager','hardcap','chat','baseevents','coop_input','brothers_world','brothers_admin','vMenu')) {
        if (@($Info.resources) -notcontains $resource) { throw ('Required resource is not started: ' + $resource) }
    }
}
function Test-LoopbackPort([int]$Port, [string]$Protocol) {
    $socket = $null
    try {
        if ($Protocol -eq 'udp') {
            $socket = New-Object Net.Sockets.UdpClient
            $socket.ExclusiveAddressUse = $true
            $socket.Client.Bind((New-Object Net.IPEndPoint([Net.IPAddress]::Loopback,$Port)))
        } else {
            $socket = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback,$Port)
            $socket.Server.ExclusiveAddressUse = $true
            $socket.Start()
        }
        return $true
    } catch [Net.Sockets.SocketException] { return $false }
    finally { if ($socket) { if ($Protocol -eq 'udp') { $socket.Dispose() } else { $socket.Stop() } } }
}
Export-ModuleMember -Function *
